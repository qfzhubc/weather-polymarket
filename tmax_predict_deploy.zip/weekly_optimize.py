# -*- coding: utf-8 -*-
"""周度优化（每周三 00:00 运行）

依据【近期预测 vs 实测】对每个机场的【每个模型】独立诊断与修正：
  ① 诊断：近一周窗口内各城各模型的 MAE / 偏差 / logloss / 精确率 / cov80 + 排名
  ② 修正：仅当偏差【统计显著】时才写入修正量（保守，只补 60%，单步上限 0.5℃）
  ③ σ 缩放：网格搜索使 80% 区间覆盖率回到 0.80（裁剪到 [0.80, 1.25]）

为什么保守：
  一周仅约 7 个新样本，噪声大。只有系统性偏差（t 检验显著）才值得修正，
  否则修正会放大噪声、损害样本外表现。所以：
    - 触发门槛：|偏差| > 0.4℃ 且 |t| > 1.6
    - 补偿比例：只补 60%，不一次性补满
    - 单步上限：|bias_adj| ≤ 0.5℃，防止累积过冲

【2026-10-19 修正】此前两个缺陷已修复：
  ① 修正量按【station】整体计算 —— 把三个模型的误差混在一起求偏差，
     得到的是"三模型平均偏差"，对任何一个模型都不对。现改为按模型独立计算。
  ② 只有 MOS 大样本 v2 接了 tuning.json；因子模型、MOS 小样本根本没读，
     等于周度优化对 2/3 的模型无效。现三个模型均接入（见各脚本 _tuned）。

输出：daily3/tuning.json 与 daily3/周度优化报告_YYYY-MM-DD.md
"""
import json
import os
import warnings
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

warnings.filterwarnings('ignore')

BASE = os.path.dirname(os.path.abspath(__file__))
D3 = os.path.join(BASE, 'daily3')
DUEL = os.path.join(D3, 'ledger_duel.csv')
TUNE = os.path.join(D3, 'tuning.json')
STATIONS = ['ZBAA', 'ZSPD', 'ZGGG']
NAME = {'ZBAA': '北京首都', 'ZSPD': '上海浦东', 'ZGGG': '广州白云'}
LBL = [('v2', 'MOS大样本v2'), ('old', '因子模型'), ('mos', 'MOS小样本')]

Z80 = 1.2816
WINDOW = 7          # ① 诊断窗口（天）
LOOKBACK = 30       # ② 修正用的近期样本数（天）
MIN_N = 8           # 少于此样本数不修正
BIAS_TRIG = 0.40    # 偏差触发门槛（℃）
T_TRIG = 1.60       # t 检验门槛
BIAS_SHARE = 0.60   # 只补 60%
ADJ_CAP = 0.50      # 单步修正上限（℃）
SCALE_LO, SCALE_HI = 0.80, 1.25
OUT = []


def p(s=''):
    print(s)
    OUT.append(s)


def _stats(s):
    """给定一组已回填的行，算诊断指标"""
    err = s['err'].values.astype(float)
    sg = s['sigma'].values.astype(float)
    n = len(err)
    if n == 0:
        return None
    bias = float(err.mean())
    se = float(np.std(err, ddof=1) / np.sqrt(n)) if n > 1 else 0.0
    t = (bias / se) if se > 1e-9 else 0.0
    return dict(n=n, mae=float(np.abs(err).mean()), bias=bias, t=t,
                ll=float(s['ll'].mean()) if 'll' in s else np.nan,
                acc=float(s['acc'].mean()) if 'acc' in s else np.nan,
                cov=float((np.abs(err) <= Z80 * sg).mean()),
                err=err, sg=sg)


def _sigma_scale(err, sg):
    """网格搜索 σ 缩放系数，使 cov80 最接近 0.80"""
    best_d, best_k = 9e9, 1.0
    for k in np.arange(0.70, 1.61, 0.02):
        d = abs(float((np.abs(err) <= Z80 * sg * k).mean()) - 0.80)
        if d < best_d:
            best_d, best_k = d, float(k)
    return float(np.clip(best_k, SCALE_LO, SCALE_HI))


def main():
    now = datetime.now()
    end = pd.Timestamp(now.strftime('%Y-%m-%d'))
    start = end - timedelta(days=WINDOW)

    if not os.path.exists(DUEL):
        print('无台账文件：%s' % DUEL)
        return
    L = pd.read_csv(DUEL)
    v = L[L['real'].notna()].copy()
    v['target_date'] = pd.to_datetime(v['target_date'])
    w = v[(v['target_date'] >= start) & (v['target_date'] < end)]

    p('# 周度优化报告 · 三地机场次日最高气温')
    p('')
    p('- 生成时间：%s' % now.strftime('%Y-%m-%d %H:%M:%S'))
    p('- 诊断窗口：**%s ~ %s**（近 %d 天，共 %d 个目标日）'
      % (start.date(), (end - timedelta(days=1)).date(),
         WINDOW, w['target_date'].nunique()))
    p('- 修正依据：各模型各自最近 **%d** 条有效记录' % LOOKBACK)
    p('')

    tuning = {'updated': now.strftime('%Y-%m-%d %H:%M:%S'),
              'window': '%s~%s' % (start.date(),
                                   (end - timedelta(days=1)).date()),
              'models': {}}

    # ---------------------------------------------------------- ① 诊断
    p('## 一、近一周各模型表现')
    p('')
    p('| 机场 | 模型 | 天数 | MAE | 偏差 | logloss | 精确率 | cov80 |')
    p('|---|---|---|---|---|---|---|---|')
    for st in STATIONS:
        g = w[w['station'] == st]
        for mdl, lbl in LBL:
            s = _stats(g[g['model'] == mdl])
            if not s:
                continue
            p('| %s | %s | %d | %.3f | %+.3f | %.4f | %.0f%% | %.0f%% |'
              % (NAME[st], lbl, s['n'], s['mae'], s['bias'], s['ll'],
                 s['acc'] * 100, s['cov'] * 100))
    p('')

    # ---------------------------------------------------------- ② 修正
    p('## 二、修正动作')
    p('')
    p('> 只有偏差通过 t 检验（|t| > %.1f 且 |偏差| > %.2f℃）才写入偏差修正，'
      '否则保持 0。σ 缩放恒执行（使 cov80 回到 0.80）。' % (T_TRIG, BIAS_TRIG))
    p('')
    p('| 机场 | 模型 | 样本 | MAE | 偏差 | t值 | cov80 前→后 | σ× | 偏差修正 |')
    p('|---|---|---|---|---|---|---|---|---|')

    for st in STATIONS:
        by = {}
        for mdl, lbl in LBL:
            rec = (v[(v['station'] == st) & (v['model'] == mdl)]
                   .sort_values('target_date').tail(LOOKBACK))
            if len(rec) < MIN_N:
                p('| %s | %s | %d | — | — | — | — | — | 样本不足，不修正 |'
                  % (NAME[st], lbl, len(rec)))
                continue
            s = _stats(rec)
            scale = _sigma_scale(s['err'], s['sg'])
            cov1 = float((np.abs(s['err']) <= Z80 * s['sg'] * scale).mean())
            if abs(s['bias']) > BIAS_TRIG and abs(s['t']) > T_TRIG:
                adj = float(np.clip(-BIAS_SHARE * s['bias'], -ADJ_CAP, ADJ_CAP))
                flag = '触发'
            else:
                adj, flag = 0.0, '未触发'
            by[mdl] = dict(n_eval=s['n'], mae=round(s['mae'], 3),
                           bias=round(s['bias'], 3), t=round(s['t'], 2),
                           cov80_before=round(s['cov'], 3),
                           cov80_after=round(cov1, 3),
                           sigma_scale=round(scale, 3),
                           bias_adj=round(adj, 3), flag=flag)
            p('| %s | %s | %d | %.3f | %+.3f | %+.2f | %.0f%%→%.0f%% | %.2f | %+.3f℃ |'
              % (NAME[st], lbl, s['n'], s['mae'], s['bias'], s['t'],
                 s['cov'] * 100, cov1 * 100, scale, adj))

        # 顶层字段沿用 v2（保持 predict_v2._tuned 向后兼容）
        top = dict(by.get('v2') or {})
        top['by_model'] = by
        tuning['models'][st] = top

    p('')

    # ---------------------------------------------------------- ③ 建议
    p('## 三、模型排名（按近一周 logloss，越小越好）')
    p('')
    for st in STATIONS:
        g = w[w['station'] == st]
        rk = []
        for mdl, lbl in LBL:
            s = _stats(g[g['model'] == mdl])
            if s and np.isfinite(s['ll']):
                rk.append((s['ll'], lbl, s['mae']))
        if rk:
            rk.sort()
            p('- **%s**：' % NAME[st]
              + '  ›  '.join('%s (ll %.3f / MAE %.2f)' % (b, a, c)
                             for a, b, c in rk))
    p('')
    p('> 说明：周度样本少，排名波动大；连续 3 周以上保持一致才视为真实差异。')

    os.makedirs(D3, exist_ok=True)
    with open(TUNE, 'w', encoding='utf-8') as f:
        json.dump(tuning, f, ensure_ascii=False, indent=1)
    print('\n→ %s' % TUNE)

    fp = os.path.join(D3, '周度优化报告_%s.md' % now.strftime('%Y-%m-%d'))
    with open(fp, 'w', encoding='utf-8') as f:
        f.write('\n'.join(OUT))
    print('→ %s' % fp)


if __name__ == '__main__':
    main()
