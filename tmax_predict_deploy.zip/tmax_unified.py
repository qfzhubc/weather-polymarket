# -*- coding: utf-8 -*-
"""
三地机场最高气温 · 统一预测框架（京 ZBAA / 沪 ZSPD / 穗 ZGGG）
================================================================
目标：尽量精确预测三地机场「次日最高气温」（METAR 整数档）。

设计原则
  1. 【统一】三城共用一套特征工程、回测、评估代码，仅按各自有效因子差异化配置
  2. 【防泄漏】所有"次日"信息必须来自 T 日可见的预报，绝不能用次日观测
  3. 【严格验证】walk-forward 样本外 + 置换检验 + logloss（替换门槛 Δ≤−0.01）
  4. 【可解释】保留格点因子，不做黑箱

核心特征（T 日视角预测 T+1 日 tmax）
  锚点类：tmax_obs（今日实测最高）
  预报类：fcst_ens（9 家模式集成）、fcst_bm（best_match）
  次日格点（来自 T 日预报）：next_sw、next_cloud_low、next_cloud、next_wind、next_mslp 等

数据源
  历史：archive.json（格点）+ multimodel.json（9家）+ asos_raw.csv（METAR）
  实时：snapshots/YYYY-MM-DD.json（每日快照，含 t850/海温/三层云）
"""
import os, sys, json, warnings, argparse
from datetime import datetime, timedelta
import numpy as np
import pandas as pd

warnings.filterwarnings('ignore')
# 路径基准 = 脚本自身所在目录（便于部署到任意环境，如 GitHub Actions）
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
from factor_study import build_features, CITIES

MODES = ["ecmwf_ifs025","ecmwf_aifs025_single","icon_seamless","ukmo_seamless",
         "meteofrance_seamless","gfs_seamless","gem_seamless","jma_seamless","cma_grapes_global"]

MODE_DIR = {'ZBAA': 'beijing', 'ZSPD': 'shanghai', 'ZGGG': ''}

# ---------------------------------------------------------------- 各城有效因子配置
# 依据：贪心前向选择 + 置换检验(n_perm=200) 双重筛选，仅保留 gain≥0.01 且 p<0.05
#   —— 严格的样本外验证，杜绝过拟合
CITY_CFG = {
    'ZBAA': dict(
        name='北京首都',
        # 单因子p<0.05: d_mslp_mean(0.025) next_precip(0.045) d_sw_noon(0.010)
        # 组合 gain=+0.0750 p=0.010  ll 1.3089→1.2340
        # 机制：冷锋气压陡降 + 降水截断 + 辐射变化（内陆干冷/下沉增温）
        add_feats=['d_mslp_mean', 'next_precip', 'd_sw_noon'],
        note='气压陡降(冷锋)+降水截断+辐射变化；北风下沉增温由锚点承接',
    ),
    'ZSPD': dict(
        name='上海浦东',
        # 关键突破：次日格点【绝对值】远强于Δ因子
        # next_cloud_day +0.2561(0.005) / next_sw_day +0.2544 / next_sw_noon +0.2495
        # next_cloud_low_pm +0.1585 / next_mslp_max +0.0432
        # 组合 gain=+0.2244 p=0.005  ll 1.2591→1.0346  acc 63.9%
        add_feats=['next_cloud_day', 'next_cloud_low_pm', 'next_mslp_max',
                   'next_sw_day', 'next_sw_noon'],
        note='低云遮阳+辐射主导（临海：次日低云/辐射绝对值直接定天花板）',
    ),
    'ZGGG': dict(
        name='广州白云',
        # 仅 next_wind_pm 稳健（+0.0557 p=0.010）；其余格点因子 p>0.11
        # 组合 gain=+0.0557 p=0.010  ll 1.2609→1.2053
        # 局地对流主导，格点尺度弱；靠锚点+模式+午后风
        add_feats=['next_wind_pm'],
        note='局地对流主导，格点因子弱；仅午后风稳健，余靠锚点+模式',
    ),
}


# ================================================================ 数据装配
def load_modes(mode_dir):
    p = os.path.join(BASE, mode_dir, 'raw_download', 'multimodel.json')
    if not os.path.exists(p):
        return None
    import multimodel as MM
    M = MM.parse_multimodel(p)
    M['date'] = pd.to_datetime(M['date'])
    return M


def build_panel(st):
    """构造统一建模面板：T 日特征 → T+1 日 tmax_obs"""
    cfg = CITIES[st]
    df = build_features(cfg['dir'])
    df['date'] = pd.to_datetime(df['date'])

    M = load_modes(MODE_DIR[st])
    if M is not None:
        df = df.merge(M, on='date', how='left')

    # ---- 目标：T+1 日实测最高
    df['y'] = df['tmax_obs'].shift(-1)

    # ---- 预报特征：T 日可见的 T+1 预报（模式列 shift(-1)）
    for m in MODES:
        if m in df.columns:
            df['fc_' + m] = df[m].shift(-1)
    fcols = ['fc_' + m for m in MODES if 'fc_' + m in df.columns]
    if fcols:
        df['fcst_ens'] = df[fcols].mean(axis=1, skipna=True)
        df['fcst_std'] = df[fcols].std(axis=1, skipna=True)

    # ---- 次日格点因子（T 日预报里的 T+1 值）——同样 shift(-1)
    grid_next = ['sw_noon','sw_day','cloud_day','cloud_pm','cloud_low_pm',
                 'wind_pm','wind_u','wind_v','wind_dir','rh_min','dew_min',
                 'tcwv','mslp_mean','mslp_max','precip','t850']
    for c in grid_next:
        if c in df.columns:
            df['next_' + c] = df[c].shift(-1)

    # ---- Δ因子（T+1 − T）
    for c in grid_next:
        if c in df.columns:
            df['d_' + c] = df[c].shift(-1) - df[c]

    # ---- 锚点
    df['anchor'] = df['tmax_obs']
    return df


# ================================================================ 实时快照注入
def _agg_snapshot_grid(grid_today, next_day, run_date):
    """把快照的 hourly 原始格点聚合成与 build_features 一致的列；同时算 next_* 列"""
    def _agg_day(rows):
        if not rows:
            return {}
        g = pd.DataFrame(rows)
        g['h'] = g['time'].str[11:13].astype(int)
        w = lambda lo, hi: g['h'].between(lo, hi)
        num = lambda c: pd.to_numeric(g[c], errors='coerce') if c in g.columns else pd.Series(dtype=float)
        out = {}
        out['cloud_day']    = num('cloud_cover')[w(8,20)].mean()
        out['cloud_pm']     = num('cloud_cover')[w(13,16)].mean()
        out['cloud_low_pm'] = num('cloud_cover_low')[w(13,16)].mean()
        out['sw_day']       = num('shortwave_radiation')[w(8,17)].mean()
        out['sw_noon']      = num('shortwave_radiation')[w(11,14)].mean()
        out['sw_sum']       = num('shortwave_radiation')[w(8,17)].sum()
        out['wind_pm']      = num('wind_speed_10m')[w(13,16)].mean()
        out['wind_max']     = num('wind_speed_10m').max()
        wd = num('wind_direction_10m')[w(11,14)].mean()
        out['wind_dir']     = wd
        out['wind_u']       = -np.sin(np.radians(wd))
        out['wind_v']       = -np.cos(np.radians(wd))
        out['t850']         = num('temperature_850hPa')[w(11,14)].mean()
        out['dew_min']      = num('dew_point_2m').min()
        out['dew_pm']       = num('dew_point_2m')[w(13,16)].mean()
        out['rh_min']       = num('relative_humidity_2m').min()
        out['tcwv']         = num('total_column_integrated_water_vapour').mean()
        out['mslp_mean']    = num('surface_pressure').mean()
        out['mslp_min']     = num('surface_pressure').min()
        out['mslp_max']     = num('surface_pressure').max()
        out['precip']       = num('precipitation').sum()
        return {k: (float(v) if pd.notna(v) else np.nan) for k, v in out.items()}

    today = {k: v for k, v in grid_today.items() if k}
    # 从 raw_grid 重新按日聚合，拿到 today 与 tomorrow 两天的完整格点
    return today


def load_snapshot(st, run_date):
    """读取指定日期快照并返回该城 dict"""
    fp = os.path.join(BASE, 'snapshots', '%s.json' % run_date)
    if not os.path.exists(fp):
        return None
    rec = json.load(open(fp, encoding='utf-8'))
    return rec.get('cities', {}).get(st)


def snapshot_row(st, run_date):
    """把快照转成一行 T 日特征（含 next_* 次日格点），列名与 build_panel 对齐"""
    c = load_snapshot(st, run_date)
    if not c:
        return None
    nxt = (datetime.strptime(run_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')

    def agg_on(rows, day):
        # 兼容两种格式：dict-of-lists（Open-Meteo）或 list-of-dicts
        if isinstance(rows, dict):
            g = pd.DataFrame(rows)
        else:
            g = pd.DataFrame(rows or [])
        if not len(g) or 'time' not in g.columns:
            return {}
        g = g[g['time'].astype(str).str.startswith(day)]
        if not len(g):
            return {}
        g['h'] = g['time'].astype(str).str[11:13].astype(int)
        w = lambda lo, hi: g['h'].between(lo, hi)
        num = lambda col: pd.to_numeric(g[col], errors='coerce') if col in g.columns else pd.Series([np.nan])
        o = {}
        o['cloud_day']    = num('cloud_cover')[w(8,20)].mean()
        o['cloud_pm']     = num('cloud_cover')[w(13,16)].mean()
        o['cloud_low_pm'] = num('cloud_cover_low')[w(13,16)].mean()
        o['sw_day']       = num('shortwave_radiation')[w(8,17)].mean()
        o['sw_noon']      = num('shortwave_radiation')[w(11,14)].mean()
        wd = num('wind_direction_10m')[w(11,14)].mean()
        o['wind_pm']      = num('wind_speed_10m')[w(13,16)].mean()
        o['wind_max']     = num('wind_speed_10m').max()
        o['wind_dir']     = wd
        o['wind_u']       = -np.sin(np.radians(wd))
        o['wind_v']       = -np.cos(np.radians(wd))
        o['dew_min']      = num('dew_point_2m').min()
        o['rh_min']       = num('relative_humidity_2m').min()
        o['tcwv']         = num('total_column_integrated_water_vapour').mean()
        o['mslp_mean']    = num('surface_pressure').mean()
        o['mslp_max']     = num('surface_pressure').max()
        o['precip']       = num('precipitation').sum()
        o['t850']         = num('temperature_850hPa')[w(11,14)].mean()
        return {k: (float(v) if pd.notna(v) else np.nan) for k, v in o.items()}

    raw_grid = c.get('raw_grid') or []
    g_today = agg_on(raw_grid, run_date)
    g_next = agg_on(raw_grid, nxt)

    # 今日实况最高（快照记录）
    anchor = c.get('obs_max_sofar')
    if anchor is None and c.get('metar'):
        temps = [m['temp'] for m in c['metar'] if m.get('temp') is not None]
        anchor = max(temps) if temps else np.nan

    # 次日预报集成（快照记录 ens_mean / best_match）
    nd = c.get('next_day_pred', {}) or {}
    fcst_ens = nd.get('ens_mean')

    row = {'date': pd.Timestamp(run_date), 'anchor': anchor, 'tmax_obs': anchor,
           'fcst_ens': fcst_ens}
    for k, v in g_today.items():
        row[k] = v
    for k, v in g_next.items():
        row['next_' + k] = v
    # Δ 因子
    for k in g_today:
        if k in g_next:
            row['d_' + k] = (g_next[k] - g_today[k]) if (pd.notna(g_next[k]) and pd.notna(g_today[k])) else np.nan
    # 缺失的 t850 用快照 grid_today 兜底
    if (pd.isna(row.get('t850')) or row.get('t850') in (0, None)) and c.get('grid_today', {}).get('t850_noon'):
        row['t850'] = c['grid_today']['t850_noon']
    return row


# ================================================================ 建模与评估
def _make_xy(df, feats):
    X = df[feats].copy()
    y = df['y'].copy()
    ok = X.notna().all(axis=1) & y.notna()
    return X[ok], y[ok]


def fit_predict(Xtr, ytr, Xte, alpha=1.0):
    from sklearn.linear_model import Ridge
    from sklearn.preprocessing import StandardScaler
    sc = StandardScaler().fit(Xtr)
    m = Ridge(alpha=alpha).fit(sc.transform(Xtr), ytr)
    mu = m.predict(sc.transform(Xte))
    res = ytr - m.predict(sc.transform(Xtr))
    return mu, max(res.std(), 0.4)


def logloss_int(mu, sig, ytrue):
    from scipy.stats import norm
    tot, n = 0.0, 0
    for m_, y_ in zip(mu, ytrue):
        k = int(round(y_))
        p = norm.cdf(k+0.5, m_, sig) - norm.cdf(k-0.5, m_, sig)
        tot += -np.log(max(p, 1e-6)); n += 1
    return tot / max(n, 1)


def _oot_sigma(train, feats, alpha=1.0, min_train=25):
    """用 walk-forward 的【样本外残差】std 估计 σ（自然校准）

    目的：替代原先 `max(残差σ, 实测日际变率×0.75)` 的下限保护。
    样本外残差直接反映模型真实误差水平，无需再叠加气候变率做下限。
    """
    from sklearn.linear_model import Ridge
    from sklearn.preprocessing import StandardScaler
    d = train.sort_values('date').reset_index(drop=True)
    idx = d.index.tolist()
    res = []
    for i in range(min_train, len(idx)):
        tr, te = idx[:i], idx[i:i + 1]
        Xtr, ytr = _make_xy(d.loc[tr], feats)
        Xte, yte = _make_xy(d.loc[te], feats)
        if len(Xtr) < min_train or not len(yte):
            continue
        sc = StandardScaler().fit(Xtr)
        m = Ridge(alpha=alpha).fit(sc.transform(Xtr), ytr)
        mu = float(m.predict(sc.transform(Xte))[0])
        res.append(mu - float(yte.iloc[0]))
    if len(res) < 6:
        return np.nan
    return float(np.std(res, ddof=1))


def walk_forward(df, feats, min_train=25, alpha=1.0):
    d = df.sort_values('date').reset_index(drop=True)
    X, y = _make_xy(d, feats)
    idx = X.index.tolist()
    mus, reals, sigs, preds = [], [], [], []
    for i in range(min_train, len(idx)):
        tr, te = idx[:i], idx[i:i+1]
        mu, sig = fit_predict(X.loc[tr], y.loc[tr], X.loc[te], alpha)
        mus.append(mu[0]); sigs.append(sig); reals.append(y.loc[te].iloc[0])
        preds.append(int(round(mu[0])))
    if not reals:
        return dict(ll=np.nan, acc=np.nan, n=0, mae=np.nan, sig=np.nan)
    reals = np.array(reals); mus = np.array(mus); preds = np.array(preds)
    sig = float(np.mean(sigs))
    ll = logloss_int(mus, sig, reals)
    acc = (preds == np.round(reals)).mean()
    mae = np.abs(mus - reals).mean()
    return dict(ll=ll, acc=acc, n=len(reals), mae=mae, sig=sig,
                preds=preds, reals=reals, mus=mus)


def perm_test(df, feats, base_feats, n_perm=150, min_train=25, seed=0):
    rng = np.random.default_rng(seed)
    ref = walk_forward(df, base_feats, min_train)['ll']
    cur = walk_forward(df, feats, min_train)['ll']
    gain = ref - cur
    null = []
    d0 = df.copy()
    for _ in range(n_perm):
        d2 = d0.copy()
        d2['y'] = rng.permutation(d2['y'].values)
        a = walk_forward(d2, base_feats, min_train)['ll']
        b = walk_forward(d2, feats, min_train)['ll']
        null.append(a - b)
    null = np.array(null)
    p = (np.sum(null >= gain) + 1) / (len(null) + 1)
    return gain, p


# ================================================================ 评估报告
def evaluate_city(st, verbose=True):
    cfg = CITY_CFG[st]
    df = build_panel(st)
    df = df[df['fcst_ens'].notna()].copy() if 'fcst_ens' in df.columns else df

    base = ['anchor', 'fcst_ens']
    add = cfg['add_feats']
    feats = base + [a for a in add if a in df.columns]

    rb = walk_forward(df, base)
    rf = walk_forward(df, feats)
    gain, p = perm_test(df, feats, base, n_perm=60)

    out = dict(st=st, name=cfg['name'], n=rf['n'],
               base_ll=rb['ll'], final_ll=rf['ll'], d_ll=rf['ll']-rb['ll'],
               base_acc=rb['acc'], final_acc=rf['acc'], mae=rf['mae'],
               gain=gain, p=p, feats=feats)

    if verbose:
        print('='*72)
        print(f"  {cfg['name']}（{st}）  n={rf['n']}   [{cfg['note']}]")
        print('='*72)
        print(f"  基线 [anchor+ensemble]      logloss={rb['ll']:.4f}  精确={rb['acc']*100:5.1f}%")
        print(f"  最终 [+{'/'.join(add) if add else '无'} ] logloss={rf['ll']:.4f}  精确={rf['acc']*100:5.1f}%  MAE={rf['mae']:.3f}")
        flag = '✅采纳' if (gain >= 0.01 and p < 0.05) else ('△弱' if gain >= 0.01 else '—')
        print(f"  增量 gain={gain:+.4f}  p={p:.3f}  {flag}")
        print(f"  残差 σ={rf['sig']:.3f}")
        print()
    return out, df, feats


# ================================================================ 生产预测
def predict_next(st, feats=None, verbose=True, run_date=None):
    """预测次日最高气温（整数档概率）
    run_date: 指定 T 日（默认取最新快照日；无快照则回退历史面板）
    """
    from scipy.stats import norm
    cfg = CITY_CFG[st]
    df = build_panel(st)
    feats = feats or (['anchor', 'fcst_ens'] + cfg['add_feats'])
    feats = [f for f in feats if f in df.columns]

    train = df[df['y'].notna()].copy()

    # ---------- 优先：实时快照行（T 日 = run_date） ----------
    row = None
    snap_dates = []
    snapdir = os.path.join(BASE, 'snapshots')
    if os.path.isdir(snapdir):
        snap_dates = sorted(f[:-5] for f in os.listdir(snapdir)
                            if f.endswith('.json') and f[0].isdigit())
    if not run_date and snap_dates:
        run_date = snap_dates[-1]
    if run_date and run_date in snap_dates:
        sr = snapshot_row(st, run_date)
        if sr is not None:
            row = pd.Series(sr)
            # 用历史分布补齐缺失的顺位特征（仅补非核心因子的缺）
            if verbose:
                print(f"  [实时注入] 使用 {run_date} 快照（锚点={sr.get('anchor')} 集成={sr.get('fcst_ens')}）")

    # ---------- 回退：历史面板最后一行 ----------
    if row is None:
        cur = df[df['y'].isna() & df['fcst_ens'].notna()]
        if not len(cur):
            cur = df[df['fcst_ens'].notna()].tail(1)
        if not len(cur):
            return None
        row = cur.iloc[-1]

    Xtr, ytr = _make_xy(train, feats)
    vals = [row.get(f, np.nan) for f in feats]
    xin = pd.DataFrame([vals], columns=feats)
    miss = [f for f, v in zip(feats, vals) if pd.isna(v)]
    if miss:
        # 缺失特征用训练均值填充，避免直接失败
        for f in miss:
            xin[f] = Xtr[f].mean()
        if verbose and len(miss) < len(feats):
            print(f"  [注意] 缺特征 {miss} → 以训练均值填充")
        if len(miss) == len(feats):
            return None
    mu, sig = fit_predict(Xtr, ytr, xin)
    base_mu = float(mu[0])

    # ---------- 天气型条件修正层 ----------
    # 动机：极端天气型（暴涨云/强降水/辐射崩塌）在历史中样本稀少，
    #       线性模型会外推失准（如北京强降水样本恰好是夏季闷热对流日，
    #       导致 next_precip 系数为正）。
    # 做法：以【次日正午短波辐射】为天气强度代理，按季节条件化。
    #       辐射越低 → 云盖/降水越强 → 白天升温越受限。
    #       在历史辐射箱内取实证 Δtmax 中位；对超出历史最低辐射的极端值，
    #       按最冷箱的 Δ 外推（单调、稳健）。
    wtype = None
    sw_next = row.get('next_sw_noon', np.nan)
    if pd.notna(sw_next):
        tr = train.copy()
        tr['_dt'] = tr['y'] - tr['anchor']
        tr['_mon'] = pd.to_datetime(tr['date']).dt.month
        cur_mon = pd.to_datetime(row['date']).month
        autumn = cur_mon >= 9
        # 季节内历史辐射分位
        sub = tr[tr['_mon'] >= 9] if autumn else tr[tr['_mon'] < 9]
        if len(sub) >= 10:
            p10 = sub['next_sw_noon'].quantile(0.10)
            p25 = sub['next_sw_noon'].quantile(0.25)
            # 触发条件：明日辐射低于季节内 25 分位
            if sw_next < p25:
                if sw_next <= p10:
                    band = sub[sub['next_sw_noon'] <= p10]
                    kind = '极低辐射（超历史10分位）'
                else:
                    band = sub[(sub['next_sw_noon'] >= p10) & (sub['next_sw_noon'] <= p25)]
                    kind = '低辐射（10-25分位）'
                if len(band) >= 2:
                    d_corr = float(band['_dt'].median())
                    wtype = dict(kind=kind + ('·秋' if autumn else '·夏'),
                                 d_corr=d_corr, n=len(band),
                                 season='秋' if autumn else '夏',
                                 sw_next=float(sw_next), p10=float(p10), p25=float(p25))
    if wtype is not None:
        # 融合：模型值 与 (锚点+天气型Δ)；秋冬强信号权重更高
        anchor_v = row.get('anchor', np.nan)
        if pd.notna(anchor_v):
            alt = float(anchor_v) + wtype['d_corr']
            w = 0.65 if wtype.get('season') == '秋' else 0.5
            score = (1 - w) * base_mu + w * alt
        else:
            score = base_mu
    else:
        score = base_mu

    # ---------------------------------------------------------------- σ 校准
    # 【2026-10-17 修正】原逻辑为：
    #     sig_corr = max(模型残差σ, 实测日际变率 × 0.75)；触发天气型时再 × 1.25
    # 三个问题：
    #   ① 概念错误：实测日际变率是【无条件气候变率】，用它给【模型残差】设下限，
    #      等于否认模型自身的预测能力 —— 模型越准，这个下限越不合理。
    #   ② 双重放大：天气型的 ×1.25 叠加在已被抬高的 σ 上，进一步稀释概率。
    #   ③ 样本内偏差：sig 取自训练样本内残差，本来就会低估，却又被下限反向扭曲。
    # 实测后果：三地 σ 被放大 1.5~3.3 倍，广州 cov80 高达 95.8%（理想 80%），
    #   表现为整数档概率过度分散（如广州 15/17/17/14）。
    #   这与 MOS 大样本 v2 上此前已修复的是同一个缺陷。
    # 新逻辑：用 walk-forward 的【样本外残差】std 作为 σ —— 自然校准，
    #   既不叠加气候变率下限，也不因触发天气型而额外放大。
    sig_oot = _oot_sigma(train, feats, alpha=1.0, min_train=25)
    sig_corr = max(float(sig_oot), 0.4) if np.isfinite(sig_oot) else max(sig, 0.4)

    # ---- 周度修正（2026-10-19 新增）
    # weekly_optimize.py 按 station×model 独立估计的 σ 缩放与系统性偏差补偿。
    # 此前本模型【没有接】tuning.json，周度优化对它完全无效，已修复。
    try:
        _t = json.load(open(os.path.join(BASE, 'daily3', 'tuning.json'),
                            encoding='utf-8'))
        _m = (((_t.get('models') or {}).get(st) or {})
              .get('by_model') or {}).get('old') or {}
    except Exception:
        _m = {}
    if _m:
        score = score + float(_m.get('bias_adj', 0.0))
        sig_corr = sig_corr * float(_m.get('sigma_scale', 1.0))

    k = int(round(score))
    probs = {}
    for kk in range(k-4, k+5):
        probs[kk] = float(norm.cdf(kk+0.5, score, sig_corr) - norm.cdf(kk-0.5, score, sig_corr))
    s = sum(probs.values()); probs = {a: b/s for a, b in probs.items()}

    target_date = (pd.Timestamp(row['date']) + pd.Timedelta(days=1)).strftime('%Y-%m-%d')
    R = dict(station=st, name=cfg['name'], base_date=str(pd.Timestamp(row['date']).date()),
             target_date=target_date, score=score, pred_int=k,
             sigma_model=sig, sigma_used=sig_corr, probs=probs,
             anchor=float(row['anchor']) if pd.notna(row.get('anchor', np.nan)) else None,
             fcst_ens=float(row['fcst_ens']) if pd.notna(row.get('fcst_ens', np.nan)) else None,
             feats=feats, n_train=len(ytr), model_mu=base_mu, wtype=wtype,
             source=('snapshot:' + run_date) if (run_date and run_date in snap_dates and 'snapshot_row' in globals()) else 'panel')
    if verbose:
        print('='*64)
        print(f"  {cfg['name']}（{st}）  {R['base_date']} → {R['target_date']}   [{R['source']}]")
        print('='*64)
        print(f"  连续预测  : {score:.2f} ℃" + (f"  （模型 {base_mu:.2f} → 天气型修正）" if wtype else ""))
        print(f"  预计报出  : {k} ℃")
        a_ = R['anchor']; e_ = R['fcst_ens']
        print(f"  锚点(今日): {a_:.1f} ℃ | 集成: {e_:.2f} ℃" if (a_ is not None and e_ is not None)
              else f"  锚点(今日): {a_} ℃ | 集成: {e_} ℃")
        if wtype:
            print(f"  ⚠ 天气型 : {wtype['kind']}  历史Δ中位={wtype['d_corr']:+.2f}℃ (n={wtype['n']})")
        print(f"  σ(模型/校正): {sig:.3f} / {sig_corr:.3f} ℃")
        print(f"  80% 区间  : {score-1.28*sig_corr:.1f} ~ {score+1.28*sig_corr:.1f}")
        print('  整数概率:')
        for kk in sorted(probs):
            if probs[kk] >= 0.005:
                print(f"    {kk:3d}℃ : {probs[kk]*100:5.1f}%  {'█'*int(probs[kk]*100/3)}")
        print()
    return R


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--eval', action='store_true')
    ap.add_argument('--predict', action='store_true')
    a = ap.parse_args()
    if not (a.eval or a.predict):
        a.eval = a.predict = True
    if a.eval:
        print('\n########## 三城回测评估 ##########\n')
        for st in CITIES:
            evaluate_city(st)
    if a.predict:
        print('\n########## 三城次日预测 ##########\n')
        for st in CITIES:
            predict_next(st)
