# 京沪穗三地机场次日最高气温预测

三模型并行：因子模型（`tmax_unified`）／MOS 小样本（`mos_model`）／MOS 大样本 v2（`predict_v2`）。
每日自动运行，预测台账提交回仓库，用线上真实数据持续裁决三模型优劣。

## 机场

| 代码 | 机场 |
|---|---|
| ZBAA | 北京首都 |
| ZSPD | 上海浦东 |
| ZGGG | 广州白云 |

## 自动运行

两个定时任务，都由 GitHub Actions 执行（cron 用 **UTC**）：

| 工作流 | cron (UTC) | 北京时间 | 作用 |
|---|---|---|---|
| `daily.yml` | `17 8 * * *` | 每天 16:17 | 记录当日实测 → 预测次日三地最高温 |
| `weekly.yml` | `0 16 * * 2` | 每周三 00:00 | 依据近期预测 vs 实测，修正三模型参数 |

- 日常任务为什么必须在 16:10 之后：日最高温通常 14–16 时才出现，锚点要用完整的当日实测。
  若早晨运行，锚点会取到清晨低温，导致预测系统性偏低。
- 周度任务为什么在周三零点：周二 16:17 的日常任务已把周二实测回填完毕，
  此时"上一周"的预测-实测配对完整，优化才有据可依。
- 两者共用 `concurrency: group: tmax-predict` 且 `cancel-in-progress: false`，
  不会互相取消，也不会并发写坏仓库。
- 均可在仓库 Actions 页面手动触发（`workflow_dispatch`）。

## 首次部署

```bash
cd <本目录>
git init -b main
git add .
git commit -m "feat: 三地机场最高气温预测模型"
git remote add origin git@github.com:<用户名>/<仓库名>.git
git push -u origin main
```

仓库设为 **Private**（私有仓库 Actions 每月 2000 分钟免费额度，本项目月耗约 30–60 分钟）。

## 运行产出

| 路径 | 说明 |
|---|---|
| `daily3/双模型预测_YYYY-MM-DD.md` | 当日报告：三模型预测 + 四档温度概率 + 对决态势 |
| `daily3/ledger_duel.csv` | 对决台账：每日预测 + 事后回填实况与误差 |
| `daily3/obs_daily.csv` | 三地每日实测最高气温 |
| `daily3/tuning.json` | σ 缩放与偏差补偿参数 |
| `daily3/run_YYYY-MM-DD.log` | 运行日志（含每步耗时，便于排障）|
| `snapshots/YYYY-MM-DD.json` | 当日快照：METAR + 9 家模式预报 + 格点因子 |

## 周度优化（已启用）

每周三 00:00 自动运行 `python weekly_optimize.py`，产出 `daily3/tuning.json`
与 `daily3/周度优化报告_YYYY-MM-DD.md`。

**它修什么**：对每个机场的**每个模型独立**做两件事

| 修正项 | 做法 | 触发条件 |
|---|---|---|
| σ 缩放 | 网格搜索使 80% 区间覆盖率回到 0.80，裁剪到 [0.80, 1.25] | 恒执行 |
| 偏差补偿 | 只补偏差的 60%，单步上限 0.5℃ | \|偏差\|>0.4℃ **且** \|t\|>1.6 |

**为什么这么保守**：一周只有约 7 个新样本，噪声大。只有系统性偏差（t 检验显著）
才值得修正，否则修正会放大噪声、反而损害样本外表现。

**闭环链路**：预测 → 台账记录 → 事后回填实测 → 周度诊断 → 写回 `tuning.json`
→ 三个模型下次运行时自动加载 → 再预测。参数随运行天数持续累积优化。

`tuning.json` 结构（顶层字段 = v2，兼容旧读取方式；`by_model` 分模型）：

```json
{ "models": { "ZGGG": { "sigma_scale": 0.8, "bias_adj": 0.0,
    "by_model": { "v2": {...}, "old": {...}, "mos": {...} } } } }
```

> 注意：`weekly_optimize.py` **只调参数，不改代码结构**。模型的特征、权重方案、
> 半衰期等结构性超参的变更仍需人工验证后改代码。

## 依赖

Python 3.11 + `requirements.txt`（numpy / pandas / scipy / scikit-learn / requests）。

数据源均为免费公开 API，无需密钥：
- Open-Meteo — 9 家数值模式预报、再分析格点因子
- aviationweather.gov — 机场 METAR 实测

## 设计要点

- **路径自解析**：所有路径基于脚本自身所在目录，不依赖当前工作目录，可迁移到任意环境。
- **并发锁**：`daily3/.running.lock`，重复触发时安全退出，避免并发写坏台账。
- **单步容错**：某步失败不阻断全流程（如快照失败仍用上一日快照继续预测）。
- **证据分级**：`live`（实时预测 + 事后回填）才是裁决依据；`backfill`（历史回放）仅参考——
  各模型参数都在自己的回测集上调过，回测成绩天然虚高。

## 目录说明

```
├── daily_3city.py        主流程（每日入口）
├── predict_v2.py         MOS 大样本 v2 模型（654 天历史预报）
├── mos_model.py          MOS 小样本模型
├── tmax_unified.py       因子模型
├── snapshot_daily.py     快照采集
├── weekly_optimize.py    周度优化（每周三）
├── backfill_v2_duel.py   v2 历史对决样本回填（一次性，已执行）
├── factor_study.py       因子构建（被 tmax_unified 依赖）
├── multimodel.py         多模式数据读取（被 tmax_unified 依赖）
├── hist/                 654 天历史数据集（实测 + 9 家模式预报 + 因子）
├── daily3/               台账、实测库、报告、调优参数
├── snapshots/            每日快照
├── raw_download/         广州历史模式数据（ZGGG）
├── beijing/raw_download/ 北京历史模式数据（ZBAA）
├── shanghai/raw_download/ 上海历史模式数据（ZSPD）
└── .github/workflows/
    ├── daily.yml     每日 16:17 预测
    └── weekly.yml    每周三 00:00 参数优化
```

## 对决台账样本量

周度优化要有效，每个模型都得有足够的"预测-实测"配对。`ledger_duel.csv` 现状：

| 模型 | live | backfill | 说明 |
|---|---|---|---|
| MOS大样本v2 | 6 | 1449 | backfill = 483 天/站严格样本外回放 |
| 因子模型 | 9 | 99 | |
| MOS小样本 | 9 | 99 | |

`backfill` 是 `backfill_v2_duel.py` 一次性生成的：对每个目标日只用**它之前**的数据训练，
用历史真实提前预报（previous-runs，非同化值）作特征，无信息泄漏。
