# -*- coding: utf-8 -*-
"""
MOS 大样本模型 v2 · 生产预测
==============================
训练：hist/ 下的 654 天历史（实测 + 各模式真实历史预报）
特征：9家各自预报 + 锚点 + 季节 + 各模式平均辅助变量 + 模式分歧
生产：实时拉取明日各模式预报（含各模式辅助变量），保证与训练同源

各城最优超参（由 hp_search 确定）
    ZBAA win=365  alpha=1.0
    ZSPD win=120  alpha=1.0
    ZGGG win=365  alpha=10.0
"""
import os, sys, json, warnings, argparse
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
import requests
from scipy.stats import norm
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings('ignore')
# 路径基准 = 脚本自身所在目录（便于部署到任意环境，如 GitHub Actions）
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
HIST = os.path.join(BASE, 'hist')
MODES = ["ecmwf_ifs025", "ecmwf_aifs025_single", "icon_seamless", "ukmo_seamless",
         "meteofrance_seamless", "gfs_seamless", "gem_seamless", "jma_seamless",
         "cma_grapes_global"]
WVAR = ['cloud_cover_mean', 'shortwave_radiation_sum',
        'wind_speed_10m_max', 'precipitation_sum']
CITIES = {'ZBAA': dict(name='北京首都', lat=40.0801, lon=116.5846),
          'ZSPD': dict(name='上海浦东', lat=31.1443, lon=121.8083),
          'ZGGG': dict(name='广州白云', lat=23.3924, lon=113.2988)}
# 时间加权（指数衰减）超参：既用654天大样本保证稳定，又偏重近期以适应偏差漂移
#   hl = 半衰期(天)：权重 0.5^(age/hl)
#   由 time_weight 搜索确定（兼顾全年样本外 + 重叠期表现）
# 季节渐变核参数（仅 ZBAA/ZGGG 启用；ZSPD 季节化会变差，不启用）
SEASON_SIG = 60.0   # 高斯核 sigma（DOY 尺度），对应季节专家建议的 W=120 天
# 分歧度自适应：σ ← σ0 × (当日9家分歧度 / 历史中位分歧度) ^ SPREAD_GAMMA
#   由 walk-forward 验证确定（三城 logloss 一致改善），γ=0.5 为最优
SPREAD_GAMMA = 0.5

BEST_HP = {'ZBAA': dict(hl=180, alpha=3.0),
           'ZSPD': dict(hl=180, alpha=3.0),
           'ZGGG': dict(hl=60, alpha=3.0)}
FEATS = (['fc_' + m for m in MODES] + ['anchor', 'sin_doy', 'cos_doy'] +
         ['wx_' + v for v in WVAR] + ['wx_tmin', 'ens_std'])



# 周度优化产出的修正参数（由 weekly_optimize.py 写入）
TUNE = os.path.join(BASE, 'daily3', 'tuning.json')


def _tuned(st):
    """读取周度修正参数；文件缺失或异常时回退到 BEST_HP"""
    hp = dict(BEST_HP[st])
    hp['sigma_scale'] = 1.0
    hp['bias_adj'] = 0.0
    try:
        t = json.load(open(TUNE, encoding='utf-8'))
        m = (t.get('models') or {}).get(st) or {}
        if m:
            if m.get('halflife'):
                hp['hl'] = float(m['halflife'])
            if m.get('alpha'):
                hp['alpha'] = float(m['alpha'])
            hp['sigma_scale'] = float(m.get('sigma_scale', 1.0))
            hp['bias_adj'] = float(m.get('bias_adj', 0.0))
    except Exception:
        pass
    return hp

def load_hist(st):
    o = pd.read_csv(os.path.join(HIST, '%s_obs.csv' % st))
    f = pd.read_csv(os.path.join(HIST, '%s_fcst.csv' % st))
    m = o.merge(f, on='date', how='inner')
    m = m[(m['n_obs'] >= 18) & m['tmax_obs'].notna()].copy()
    m['date'] = pd.to_datetime(m['date'])
    m = m.sort_values('date').reset_index(drop=True)
    for md in MODES:
        c = 'temperature_2m_max_' + md
        if c in m.columns:
            m['fc_' + md] = pd.to_numeric(m[c], errors='coerce')
    fcs = ['fc_' + m2 for m2 in MODES if 'fc_' + m2 in m.columns]
    m['ens_mean'] = m[fcs].mean(axis=1)
    m['ens_std'] = m[fcs].std(axis=1)
    for v in WVAR:
        cols = [v + '_' + md for md in MODES if v + '_' + md in m.columns]
        if cols:
            m['wx_' + v] = m[cols].apply(pd.to_numeric, errors='coerce').mean(axis=1)
    tm = ['temperature_2m_min_' + md for md in MODES
          if 'temperature_2m_min_' + md in m.columns]
    if tm:
        m['wx_tmin'] = m[tm].apply(pd.to_numeric, errors='coerce').mean(axis=1)
    m['anchor'] = m['tmax_obs'].shift(1)
    doy = m['date'].dt.dayofyear
    m['sin_doy'] = np.sin(2 * np.pi * doy / 365.25)
    m['cos_doy'] = np.cos(2 * np.pi * doy / 365.25)
    return m


def fetch_live_fcst(st):
    """实时拉明日各模式预报（含各模式辅助变量），与训练同源"""
    cfg = CITIES[st]
    vars_ = ['temperature_2m_max', 'temperature_2m_min', 'cloud_cover_mean',
             'shortwave_radiation_sum', 'wind_speed_10m_max', 'precipitation_sum']
    u = ('https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s'
         '&daily=%s&timezone=Asia%%2FShanghai&past_days=2&forecast_days=3'
         '&models=' % (cfg['lat'], cfg['lon'], ','.join(vars_))) + ','.join(MODES)
    try:
        j = requests.get(u, timeout=150).json()
    except Exception as e:
        return None
    if 'daily' not in j:
        return None
    d = j['daily']
    out = {}
    for i, t in enumerate(d['time']):
        r = {'date': t}
        for md in MODES:
            k = 'temperature_2m_max_' + md
            if k in d:
                r['fc_' + md] = d[k][i]
        for v in WVAR:
            vals = [d[v + '_' + md][i] for md in MODES
                    if v + '_' + md in d and d[v + '_' + md][i] is not None]
            r['wx_' + v] = float(np.mean(vals)) if vals else np.nan
        tm = [d['temperature_2m_min_' + md][i] for md in MODES
              if 'temperature_2m_min_' + md in d and d['temperature_2m_min_' + md][i] is not None]
        r['wx_tmin'] = float(np.mean(tm)) if tm else np.nan
        fcs = [r['fc_' + md] for md in MODES if 'fc_' + md in r
               and r['fc_' + md] is not None]
        r['ens_mean'] = float(np.mean(fcs)) if fcs else np.nan
        r['ens_std'] = float(np.std(fcs)) if len(fcs) > 1 else np.nan
        out[t] = r
    return out


def predict(st, target_date=None, verbose=True):
    hp = _tuned(st)          # 读取周度优化后的参数（无文件时回退 BEST_HP）
    m = load_hist(st)
    today = datetime.now().strftime('%Y-%m-%d')
    if target_date is None:
        target_date = (datetime.strptime(today, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')

    live = fetch_live_fcst(st)
    if not live or target_date not in live:
        print('%s: 无明日预报数据' % st); return None
    r = live[target_date]

    # 特征行
    ts = pd.Timestamp(target_date)
    doy = ts.dayofyear
    row = dict(date=target_date,
               sin_doy=np.sin(2 * np.pi * doy / 365.25),
               cos_doy=np.cos(2 * np.pi * doy / 365.25))
    for k in ['fc_' + md for md in MODES] + ['wx_' + v for v in WVAR] + \
             ['wx_tmin', 'ens_std', 'ens_mean']:
        row[k] = r.get(k, np.nan)

    # anchor = 目标日前一日的实测最高（优先用 hist/obs_daily，其次实时）
    prev = (ts - timedelta(days=1)).strftime('%Y-%m-%d')
    anchor = np.nan
    o = pd.read_csv(os.path.join(HIST, '%s_obs.csv' % st))
    hit = o[o['date'] == prev]
    if len(hit):
        anchor = float(hit['tmax_obs'].iloc[0])
    if np.isnan(anchor):
        odb = os.path.join(BASE, 'daily3', 'obs_daily.csv')
        if os.path.exists(odb):
            ob = pd.read_csv(odb)
            h2 = ob[(ob['station'] == st) & (ob['date'].astype(str) == prev)]
            if len(h2):
                anchor = float(h2['tmax_obs'].iloc[0])
    row['anchor'] = anchor

    feats = [f for f in FEATS if f in m.columns]
    d = m.dropna(subset=feats + ['tmax_obs']).reset_index(drop=True)

    # 用全部历史训练，但按【时间指数衰减】加权：近期样本权重大
    tr = d
    Xtr = tr[feats].values.astype(float)
    ytr = tr['tmax_obs'].values.astype(float)
    ok = ~(np.isnan(Xtr).any(axis=1) | np.isnan(ytr))
    Xtr, ytr, tr2 = Xtr[ok], ytr[ok], tr[ok]
    if 'date' not in tr2.columns:
        tr2 = tr2.reset_index()
    age = (tr2['date'].max() - tr2['date']).dt.days.values.astype(float)
    sw = 0.5 ** (age / hp['hl'])
    # ---- 季节渐变核（仅北京/广州启用）
    # 由 season_study 验证：ZBAA/ZGGG 季节化有显著收益（尤其冬季：
    #   北京1月 ll 0.885→0.726、广州4月 1.227→0.880）；
    #   而 ZSPD 季节化【会变差】（9月最易、2/12/4月难，全局模型已最优），故不启用。
    # 圆形 DOY 高斯核：天然处理季节交界，避免硬切分的额外损失(~+0.03 MAE)
    if st in ('ZBAA', 'ZGGG'):
        tgt_doy = float(pd.Timestamp(target_date).dayofyear)
        d_doy = tr2['date'].dt.dayofyear.values.astype(float)
        dd = np.abs(d_doy - tgt_doy)
        dd = np.minimum(dd, 365.25 - dd)          # 圆形距离（跨年连续）
        sK = np.exp(-(dd ** 2) / (2 * (SEASON_SIG ** 2)))
        sw = sw * sK
    sc = StandardScaler().fit(Xtr)
    mm = Ridge(alpha=hp['alpha']).fit(sc.transform(Xtr), ytr, sample_weight=sw)
    xq = np.array([[row.get(f, np.nan) for f in feats]], dtype=float)
    miss = np.isnan(xq[0])
    if miss.any():
        xq[0][miss] = np.nanmean(Xtr, axis=0)[miss]
    mu = float(mm.predict(sc.transform(xq))[0])
    res = ytr - mm.predict(sc.transform(Xtr))
    # ---- σ 校准（重要）
    # 曾用 max(resid, 实测日际变率×0.5) 做下限保护，经覆盖率检验发现
    # 该下限使概率【过宽】(上海 cov80 达 95.8%)，反而损害 logloss，已移除。
    # 现按城选用（由 sigma_check 覆盖率检验确定）：
    #   ZSPD: EWMA(60) 残差方差（近期波动自适应）
    #   ZBAA/ZGGG: 残差 σ
    if st == 'ZSPD':
        lam = 1 - 2 / (60 + 1)
        wts = lam ** np.arange(len(res) - 1, -1, -1)
        ewma_var = float(np.sum(wts * (res ** 2)) / np.sum(wts))
        sig0 = max(0.95 * float(np.sqrt(ewma_var)), 0.5)
    else:
        sig0 = max(float(res.std(ddof=1)), 0.3)

    # ---- 分歧度自适应（2026-10-18 新增）
    # 气象学上的 spread–skill 关系：模式之间的离散度越大，预报越不可信。
    # 因此用【分歧度相对历史中位】的 γ 次幂缩放 σ —— 只改不确定性，不动均值，
    # 避免"按天气型切换模式权重"那种过滤样本造成的信息损失。
    spr = float(row.get('ens_std', np.nan)) if row.get('ens_std') is not None else np.nan
    med = (float(np.nanmedian(tr2['ens_std'].values))
           if 'ens_std' in tr2.columns else np.nan)
    if np.isfinite(spr) and np.isfinite(med) and med > 1e-6:
        sig = sig0 * (spr / med) ** SPREAD_GAMMA
    else:
        sig = sig0

    # ---- 周度修正：σ 缩放 + 偏差补偿
    sig = sig * float(hp.get('sigma_scale', 1.0))
    mu = mu + float(hp.get('bias_adj', 0.0))
    k = int(round(mu))
    probs = {kk: float(norm.cdf(kk + .5, mu, sig) - norm.cdf(kk - .5, mu, sig))
             for kk in range(k - 4, k + 5)}
    s = sum(probs.values()); probs = {a: b / s for a, b in probs.items()}

    R = dict(station=st, name=CITIES[st]['name'], target_date=target_date,
             score=mu, pred_int=k, sigma=sig, probs=probs, anchor=anchor,
             ens_mean=row.get('ens_mean'), halflife=hp['hl'], alpha=hp['alpha'],
             n_train=len(ytr), feats=feats)
    if verbose:
        print('=' * 62)
        print('  %s（%s）  目标日 %s' % (R['name'], st, target_date))
        print('=' * 62)
        print('  9家集成 %.2f℃ | 锚点(前日实测) %s' %
              (R['ens_mean'], ('%.1f℃' % anchor) if not np.isnan(anchor) else '—'))
        print('  连续预测 %.2f℃  →  预计报出 %d℃   (σ=%.3f, 训练%d天)'
              % (mu, k, sig, len(ytr)))
        print('  整数概率:')
        for kk in sorted(probs):
            if probs[kk] >= 0.005:
                print('    %3d℃ : %5.1f%%  %s' % (kk, probs[kk] * 100, '█' * int(probs[kk] * 100 / 3)))
        print()
    return R


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--date', default=None)
    ap.add_argument('--st', default=None)
    a = ap.parse_args()
    sts = [a.st] if a.st else ['ZBAA', 'ZSPD', 'ZGGG']
    print('\n########## MOS 大样本模型 v2 生产预测 ##########\n')
    for st in sts:
        predict(st, target_date=a.date)
