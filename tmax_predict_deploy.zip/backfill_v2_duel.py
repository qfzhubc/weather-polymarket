# -*- coding: utf-8 -*-
"""回填 MOS 大样本 v2 的历史对决样本

为什么需要：
  v2 是 2026-10-17 才接入主流水线的，台账里只有 3 天的 live 记录；
  而因子模型 / MOS 小样本各有 ~100 天 backfill 记录。
  样本不对等 → 周度优化无法评估 v2（7 天窗口内只有 0~1 个样本），
  「自动优化」就名存实亡。

做法（严格样本外，无泄漏）：
  对每个目标日 t，只用 date < t 的样本训练，用 hist/ 里 t 日各模式的
  【真实提前预报】（previous_runs，非同化值）作为特征行，预测 t 日实测。
  训练/预测逻辑与 predict_v2.predict() 完全一致，唯一差别是
  ① 训练窗口截断到过去；② 不套用周度修正（评估的是原始模型能力）。

输出：写入 daily3/ledger_duel.csv，source='backfill'，model='v2'
"""
import json
import os
import sys
import warnings

import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings('ignore')

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

import predict_v2 as P2

DUEL = os.path.join(BASE, 'daily3', 'ledger_duel.csv')
MIN_TRAIN = 80          # 前 80 天只用于积累训练集，不产出对决样本
STATIONS = ['ZBAA', 'ZSPD', 'ZGGG']


def _pll(probs, kreal):
    """整数档 logloss（命中概率取对数，下限保护）"""
    p = probs.get(int(kreal), 0.0)
    return float(-np.log(max(p, 1e-6)))


def backfill_station(st):
    m = P2.load_hist(st)
    feats = [f for f in P2.FEATS if f in m.columns]
    d = m.dropna(subset=feats + ['tmax_obs']).sort_values('date').reset_index(drop=True)
    hp = P2.BEST_HP[st]
    rows = []

    for i in range(MIN_TRAIN, len(d)):
        tr = d.iloc[:i]
        te = d.iloc[i]
        Xtr = tr[feats].values.astype(float)
        ytr = tr['tmax_obs'].values.astype(float)
        ok = ~(np.isnan(Xtr).any(axis=1) | np.isnan(ytr))
        if ok.sum() < MIN_TRAIN:
            continue
        Xtr, ytr, tr2 = Xtr[ok], ytr[ok], tr[ok]

        # 时间指数衰减权重（与生产一致）
        age = (tr2['date'].max() - tr2['date']).dt.days.values.astype(float)
        sw = 0.5 ** (age / hp['hl'])
        # 季节圆形高斯核（仅京/穗）
        if st in ('ZBAA', 'ZGGG'):
            tgt_doy = float(te['date'].dayofyear)
            dd = np.abs(tr2['date'].dt.dayofyear.values.astype(float) - tgt_doy)
            dd = np.minimum(dd, 365.25 - dd)
            sw = sw * np.exp(-(dd ** 2) / (2 * (P2.SEASON_SIG ** 2)))

        sc = StandardScaler().fit(Xtr)
        mm = Ridge(alpha=hp['alpha']).fit(sc.transform(Xtr), ytr, sample_weight=sw)
        xq = te[feats].values.astype(float).reshape(1, -1)
        miss = np.isnan(xq[0])
        if miss.any():
            xq[0][miss] = np.nanmean(Xtr, axis=0)[miss]
        mu = float(mm.predict(sc.transform(xq))[0])
        res = ytr - mm.predict(sc.transform(Xtr))

        # σ（与生产一致）
        if st == 'ZSPD':
            lam = 1 - 2 / (60 + 1)
            wts = lam ** np.arange(len(res) - 1, -1, -1)
            sig0 = max(0.95 * float(np.sqrt(np.sum(wts * (res ** 2)) / np.sum(wts))), 0.5)
        else:
            sig0 = max(float(res.std(ddof=1)), 0.3)
        spr = float(te.get('ens_std', np.nan)) if 'ens_std' in te.index else np.nan
        med = float(np.nanmedian(tr2['ens_std'].values)) if 'ens_std' in tr2.columns else np.nan
        sig = sig0 * (spr / med) ** P2.SPREAD_GAMMA if (
            np.isfinite(spr) and np.isfinite(med) and med > 1e-6) else sig0

        k = int(round(mu))
        probs = {int(kk): float(norm.cdf(kk + .5, mu, sig) - norm.cdf(kk - .5, mu, sig))
                 for kk in range(k - 4, k + 5)}
        s = sum(probs.values())
        probs = {a: b / s for a, b in probs.items()}
        real = float(te['tmax_obs'])

        rows.append(dict(
            target_date=str(pd.Timestamp(te['date']).date()), station=st, model='v2',
            source='backfill', pred=mu, pred_int=k, sigma=sig, real=real,
            err=mu - real, ll=_pll(probs, int(round(real))),
            acc=1.0 if k == int(round(real)) else 0.0,
            probs=json.dumps({str(a): round(b, 5) for a, b in probs.items()})))

    return pd.DataFrame(rows)


def main():
    allnew = []
    for st in STATIONS:
        df = backfill_station(st)
        allnew.append(df)
        v = df
        print('%s: %d 天  MAE %.3f  偏差 %+.3f  logloss %.4f  精确率 %.1f%%'
              % (st, len(v), v['err'].abs().mean(), v['err'].mean(),
                 v['ll'].mean(), v['acc'].mean() * 100))
    new = pd.concat(allnew, ignore_index=True)

    if os.path.exists(DUEL):
        L = pd.read_csv(DUEL)
        nk = set(zip(new['station'], new['target_date'], new['model']))
        keep = [k not in nk for k in zip(L['station'], L['target_date'], L['model'])]
        L = pd.concat([L[keep], new], ignore_index=True)
    else:
        L = new
    L = (L.drop_duplicates(subset=['station', 'target_date', 'model'], keep='last')
           .sort_values(['target_date', 'station', 'model']).reset_index(drop=True))
    L.to_csv(DUEL, index=False)
    print('\n→ %s   共 %d 行' % (DUEL, len(L)))
    print(L.groupby(['model', 'source']).size().to_string())


if __name__ == '__main__':
    main()
