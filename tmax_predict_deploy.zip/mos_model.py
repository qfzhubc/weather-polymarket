# -*- coding: utf-8 -*-
"""
机场最高气温 · MOS（模式输出统计）订正模型
============================================
核心思想
--------
各国预报中心输出的是【格点/区域平均】最高气温，机场 METAR 是【单点】实测。
二者之间是系统性、可学习的差异。用历史「预报 vs 实测」对比学习这个映射。

与旧框架(tmax_unified)的关键区别 —— 修复泄漏
---------------------------------------------
旧框架用 archive.json 的 next_* 因子（ERA5 再分析，含事后信息）→ 回测虚高。
本模型只用 multimodel.json 中【各家模式自己发布的预报】:
  temperature_2m_max_{mode}     各家对当日最高温的预报
  cloud_cover_mean_{mode}       各家自己报的云量
  shortwave_radiation_sum_{m}   各家自己报的辐射
  wind_speed_10m_max_{m}        各家自己报的风速
  precipitation_sum_{m}         各家自己报的降水
这些都是预报实时发布的，回测与生产同源，无事后信息。

三层架构
--------
L1 融合层: 9 家预报 → 非负凸组合最优权重（simplex 约束 + 向等权收缩 + 嵌套选 λ）
L2 订正层: 用模式积分预报的天气型做条件订正（仅在样本外验证有效时启用）
L3 概率层: 正态离散化输出整数档概率 + 上尾校正

验证标准（沿用用户约定）
------------------------
walk-forward 样本外 + 置换检验；logloss 至少降 0.01 且 p<0.05 才替换现有模型
"""
import os, sys, json, warnings, argparse
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

warnings.filterwarnings('ignore')
try:
    from scipy.optimize import minimize
    from scipy.stats import norm
    from sklearn.linear_model import Ridge
except ImportError:
    pass

SEED = 201806127

MODES = ["ecmwf_ifs025", "ecmwf_aifs025_single", "icon_seamless", "ukmo_seamless",
         "meteofrance_seamless", "gfs_seamless", "gem_seamless", "jma_seamless",
         "cma_grapes_global"]

# 各模式所属国家/机构（用户关心的"中美欧加"）
ORIGIN = {
    'ecmwf_ifs025': '欧洲(ECMWF)',
    'ecmwf_aifs025_single': '欧洲(ECMWF-AI)',
    'icon_seamless': '德国(DWD)',
    'ukmo_seamless': '英国(UKMO)',
    'meteofrance_seamless': '法国(MF)',
    'gfs_seamless': '美国(NCEP)',
    'gem_seamless': '加拿大(CMC)',
    'jma_seamless': '日本(JMA)',
    'cma_grapes_global': '中国(CMA)',
}

CITIES = {
    'ZBAA': dict(name='北京首都', dir='beijing'),
    'ZSPD': dict(name='上海浦东', dir='shanghai'),
    'ZGGG': dict(name='广州白云', dir=''),
}

# 回测参数（由回测验证专家建议）
MIN_TRAIN = 28      # 最小训练天数
W_ROLL = 21         # 动态权重的滚动窗口
LAM_GRID = [0.1, 0.5, 1.0, 3.0, 10.0]   # 收缩系数网格

# 模块级路径基准（脚本自身所在目录），使部署到任意环境都能定位数据
BASE = os.path.dirname(os.path.abspath(__file__))


# ================================================================ 数据加载
def load_city(st):
    """加载某城的【模式预报】与【机场实测】，返回对齐后的日期表"""
    cfg = CITIES[st]
    _BASE = os.path.dirname(os.path.abspath(__file__))
    raw = _BASE if cfg['dir'] == '' else os.path.join(_BASE, cfg['dir'])
    raw = os.path.join(raw, 'raw_download')

    # --- 机场实测（METAR，UTC→按日取最高）
    a = pd.read_csv(os.path.join(raw, 'asos_raw.csv'))
    a['valid'] = pd.to_datetime(a['valid'], errors='coerce')
    a['date'] = a['valid'].dt.date.astype(str)
    a = a[pd.to_numeric(a['tmpf'], errors='coerce').notna()]
    a['t_c'] = (pd.to_numeric(a['tmpf'], errors='coerce') - 32) * 5 / 9
    obs = a.groupby('date')['t_c'].max()

    # --- 各模式预报（含各家自己报的辅助变量）
    j = json.load(open(os.path.join(raw, 'multimodel.json')))
    dd = j['daily']
    df = pd.DataFrame({k: v for k, v in dd.items() if k != 'time'}, index=dd['time'])
    df.index.name = 'date'

    # 各家 T+1 最高温预报（列名 fc_{mode}）
    out = pd.DataFrame(index=df.index)
    for m in MODES:
        c = 'temperature_2m_max_' + m
        out['fc_' + m] = pd.to_numeric(df[c], errors='coerce') if c in df.columns else np.nan

    # 各家自己报的辅助天气变量（集成平均，用于天气型订正）
    for var in ['cloud_cover_mean', 'shortwave_radiation_sum',
                'wind_speed_10m_max', 'precipitation_sum']:
        cols = [var + '_' + m for m in MODES if var + '_' + m in df.columns]
        if cols:
            out['wx_' + var] = df[cols].apply(pd.to_numeric, errors='coerce').mean(axis=1)

    out['tmax_obs'] = obs.reindex(out.index)
    out = out.reset_index().rename(columns={'index': 'date'})
    out['date'] = pd.to_datetime(out['date'])
    return out


# ================================================================ L1 融合层
def fit_simplex(X, y, lam, w_eq=None):
    """非负凸组合: min ||Xw-y||² + λn||w-w_eq||²  s.t. Σw=1, w≥0
    返回权重 w"""
    n, p = X.shape
    if w_eq is None:
        w_eq = np.ones(p) / p

    def obj(w):
        r = X.dot(w) - y
        return float((r * r).sum() + lam * n * ((w - w_eq) ** 2).sum())

    def grad(w):
        r = X.dot(w) - y
        return 2 * X.T.dot(r) + 2 * lam * n * (w - w_eq)

    cons = [{'type': 'eq', 'fun': lambda w: float(w.sum() - 1)}]
    res = minimize(obj, w_eq.copy(), jac=grad, bounds=[(0, 1)] * p,
                   constraints=cons, method='SLSQP',
                   options={'maxiter': 800, 'ftol': 1e-10})
    w = np.clip(res.x, 0, None)
    s = w.sum()
    return w / s if s > 0 else np.ones(p) / p


def select_lam(X, y, grid=LAM_GRID):
    """嵌套选 λ: 训练窗口内做留一交叉验证，避免选择偏差"""
    if len(y) < 8:
        return 1.0
    best, best_err = grid[0], np.inf
    for lam in grid:
        errs = []
        for i in range(len(y)):
            tr = np.arange(len(y)) != i
            try:
                w = fit_simplex(X[tr], y[tr], lam)
                errs.append((X[i].dot(w) - y[i]) ** 2)
            except Exception:
                errs.append(np.nan)
        e = np.nanmean(errs)
        if np.isfinite(e) and e < best_err:
            best_err, best = e, lam
    return best


# ================================================================ 评估工具
def logloss_int(mu, sig, ytrue):
    tot, n = 0.0, 0
    for m_, y_ in zip(np.atleast_1d(mu), np.atleast_1d(ytrue)):
        k = int(round(y_))
        p = norm.cdf(k + 0.5, m_, sig) - norm.cdf(k - 0.5, m_, sig)
        tot += -np.log(max(p, 1e-6)); n += 1
    return tot / max(n, 1)


def metrics(mus, sig, reals):
    reals = np.asarray(reals); mus = np.asarray(mus)
    return dict(ll=logloss_int(mus, sig, reals),
                acc=float((np.round(mus) == np.round(reals)).mean()),
                mae=float(np.abs(mus - reals).mean()),
                bias=float((mus - reals).mean()),
                n=len(reals))


# ================================================================ walk-forward
def walk_forward_mos(st, scheme='mos', min_train=MIN_TRAIN, w_roll=W_ROLL,
                     nested_lam=True, bias_mode='rolling', lam=None,
                     alpha=3.0, verbose=False):
    """逐日 walk-forward 样本外回测

    scheme: 'equal' | 'best_single' | 'mos'(非负凸组合) | 'ridge'
    bias_mode: 'none'(不订正) | 'rolling'(用最近w_roll天偏差) | 'full'(全期偏差)
               —— 关键：诊断显示北京偏差随季节漂移，'full' 全局订正有害，
                  故默认 'rolling'
    """
    df = load_city(st)
    fcols = ['fc_' + m for m in MODES]
    p = len(fcols)
    n = len(df)
    rows = []

    def _xy(d):
        X = d[fcols].values.astype(float)
        y = d['tmax_obs'].values.astype(float)
        ok = ~(np.isnan(X).any(axis=1) | np.isnan(y))
        return X[ok], y[ok]

    for i in range(min_train, n):
        Xr, yr = _xy(df.iloc[max(0, i - w_roll):i])   # 滚动窗口：拟合权重
        Xf, yf = _xy(df.iloc[:i])                      # 全期：备用
        if len(yr) < 5 or len(yf) < 5:
            continue

        xte = df.iloc[i][fcols].values.astype(float).reshape(1, -1)
        if np.isnan(xte).any():
            continue
        yte = df.iloc[i]['tmax_obs']
        if pd.isna(yte):
            continue

        # ---------- 拟合预测器 f ----------
        if scheme == 'equal':
            w = np.ones(p) / p
            f = lambda Z: Z @ w
        elif scheme == 'mos':
            _lam = select_lam(Xr, yr) if nested_lam else (lam if lam is not None else 1.0)
            w = fit_simplex(Xr, yr, _lam)
            f = lambda Z: Z @ w
        elif scheme == 'ridge':
            from sklearn.preprocessing import StandardScaler
            sc = StandardScaler().fit(Xr)
            mm = Ridge(alpha=alpha).fit(sc.transform(Xr), yr)
            w = mm.coef_
            f = lambda Z: mm.predict(sc.transform(Z))   # 注意：必须过同一个 scaler
        elif scheme == 'best_single':
            errs = np.abs(Xr - yr.reshape(-1, 1)).mean(axis=0)
            w = np.zeros(p); w[int(np.argmin(errs))] = 1.0
            f = lambda Z: Z @ w
        else:
            raise ValueError(scheme)

        # ---------- 偏差订正 c 与残差 std ----------
        if bias_mode == 'none':
            c = 0.0
            resid = yf - f(Xf)
        elif bias_mode == 'rolling':
            mt = f(Xr)
            c = float((yr - mt).mean())
            resid = yr - mt - c
        else:   # 'full'
            mt = f(Xf)
            c = float((yf - mt).mean())
            resid = yf - mt - c

        mu = float(np.atleast_1d(f(xte))[0] + c)
        sig = max(float(np.std(resid, ddof=1)) if len(resid) > 2 else 0.8, 0.4)
        rows.append(dict(date=df.iloc[i]['date'], mu=mu, real=yte, c=c, sig=sig,
                         w=np.asarray(w, dtype=float).copy()))

    if not rows:
        return dict(scheme=scheme, n=0, ll=np.nan, acc=np.nan, mae=np.nan,
                    bias=np.nan, rows=[])
    R = pd.DataFrame(rows)
    sig = float(R['sig'].mean())
    M = metrics(R['mu'].values, sig, R['real'].values)
    M.update(dict(scheme=scheme, bias_mode=bias_mode, rows=rows,
                  mean_c=float(R['c'].mean()),
                  ws=np.mean([r['w'] for r in rows], axis=0)))
    return M


def compare_schemes(st, min_train=MIN_TRAIN):
    """对比各融合方案"""
    res = {}
    for s in ['equal', 'best_single', 'ridge', 'mos']:
        res[s] = walk_forward_mos(st, scheme=s, min_train=min_train)
    return res


def perm_test_mos(st, min_train=MIN_TRAIN, n_perm=200, seed=SEED):
    """置换检验: MOS 相对等权集成的改进是否显著"""
    rng = np.random.default_rng(seed)
    df = load_city(st)
    base = walk_forward_mos(st, 'equal', min_train)
    cur = walk_forward_mos(st, 'mos', min_train)
    gain = base['ll'] - cur['ll']

    reals = np.array([r['real'] for r in cur['rows']])
    mus_cur = np.array([r['mu'] for r in cur['rows']])
    mus_base = np.array([r['mu'] for r in base['rows']])
    sig = np.mean([r['sig'] for r in cur['rows']])

    null = []
    for _ in range(n_perm):
        yp = rng.permutation(reals)
        a = logloss_int(mus_base, sig, yp)
        b = logloss_int(mus_cur, sig, yp)
        null.append(a - b)
    null = np.array(null)
    p = float((np.sum(null >= gain) + 1) / (len(null) + 1))
    return gain, p, base, cur


# ================================================================ 最终配置
# 由 final_decision 实证确定：每城在 {无L2, 云量, 辐射, 风速, 降水} 中挑 logloss 最优
# 由 final_decision + mos_calib(概率校准搜索) 实证确定
# sigma_k: σ 下限保护系数，修正「残差σ系统性低于真实不确定性」导致的概率过度自信
#          σ_used = max(残差σ, 滚动实测日际变率 × k)
MOS_CFG = {
    'ZBAA': dict(name='北京首都', l2=None, sigma_k=0.5,
                 note='偏差随季节漂移 → 滚动21天偏差订正；天气型因子无增益；σ需下限保护(k=0.5)'),
    'ZSPD': dict(name='上海浦东', l2='wx_shortwave_radiation_sum', sigma_k=0.5,
                 note='辐射订正增益最大：logloss 1.26→0.86，精确率 45%→72%'),
    'ZGGG': dict(name='广州白云', l2='wx_shortwave_radiation_sum', sigma_k=0.5,
                 note='弱增益；σ已够大，k 影响在噪声范围内'),
}


def mos_sigma(tr, resid, k=0.5, floor=0.3):
    """统一 σ 估计：max(残差σ, 滚动实测日际变率×k, floor)
    回测与生产必须用同一个公式，否则评估失真"""
    base = max(float(np.std(resid, ddof=1)) if len(resid) > 2 else floor, floor)
    try:
        ts = float(tr['tmax_obs'].dropna().diff().abs().std())
        if not np.isfinite(ts):
            ts = 0.0
    except Exception:
        ts = 0.0
    return max(base, ts * k)


def predict_final(st, target_date=None, verbose=True, w_roll=W_ROLL):
    """最终 MOS 预测：L1 滚动偏差订正 + (可选)L2 天气型订正 → 整数档概率"""
    cfg_m = MOS_CFG[st]
    lv = cfg_m['l2']
    df = load_city(st)
    fcols = ['fc_' + m for m in MODES]

    if target_date:
        cand = df[df['date'] == pd.Timestamp(target_date)]
    else:
        # 默认：预测【明天】
        tomorrow = pd.Timestamp(datetime.now().strftime('%Y-%m-%d')) + pd.Timedelta(days=1)
        cand = df[df['date'] == tomorrow]
        if not len(cand):   # 回退：最后一个有预报的日子
            cand = df[df['fc_' + MODES[0]].notna()].tail(1)
    if not len(cand):
        return None
    row = cand.iloc[-1]
    i = df.index[df['date'] == row['date']][0]

    tr = df.iloc[max(0, i - w_roll):i]
    X = tr[fcols].values.astype(float)
    y = tr['tmax_obs'].values.astype(float)
    ok = ~(np.isnan(X).any(axis=1) | np.isnan(y))
    X, y = X[ok], y[ok]
    if len(y) < 8:
        return None
    Wz = None
    if lv:
        Wz = tr[[lv]].values.astype(float)[ok]
        m2 = ~np.isnan(Wz).any(axis=1)
        if m2.sum() < 8:
            return None
        X, y, Wz = X[m2], y[m2], Wz[m2]

    ens = X.mean(axis=1)
    c = float((y - ens).mean())
    resid = y - ens - c
    beta = mw = sw = 0.0
    if Wz is not None:
        mw, sw = Wz[:, 0].mean(), Wz[:, 0].std() + 1e-9
        zz = (Wz[:, 0] - mw) / sw
        beta = float(np.mean(zz * resid) / (np.mean(zz * zz) + 1e-9))
        resid = resid - beta * zz

    x = row[fcols].values.astype(float)
    if np.isnan(x).any():
        return None
    score = float(np.nanmean(x) + c)
    l2_contrib = 0.0
    if Wz is not None and pd.notna(row[lv]):
        l2_contrib = beta * (float(row[lv]) - mw) / sw
        score += l2_contrib

    # σ：与回测完全一致的公式（含 k 下限保护）
    sig = mos_sigma(tr, resid, cfg_m.get('sigma_k', 0.5))
    sig_use = sig

    # ---- 周度修正（2026-10-19 新增）
    # 此前本模型【没有接】tuning.json，周度优化对它完全无效，已修复。
    try:
        _t = json.load(open(os.path.join(BASE, 'daily3', 'tuning.json'),
                            encoding='utf-8'))
        _m = (((_t.get('models') or {}).get(st) or {})
              .get('by_model') or {}).get('mos') or {}
    except Exception:
        _m = {}
    if _m:
        score = score + float(_m.get('bias_adj', 0.0))
        sig_use = sig_use * float(_m.get('sigma_scale', 1.0))

    k = int(round(score))
    probs = {kk: float(norm.cdf(kk + 0.5, score, sig_use) - norm.cdf(kk - 0.5, score, sig_use))
             for kk in range(k - 4, k + 5)}
    ss = sum(probs.values())
    probs = {a: b / ss for a, b in probs.items()}

    R = dict(station=st, name=CITIES[st]['name'], note=cfg_m['note'],
             date=str(pd.Timestamp(row['date']).date()),
             score=score, pred_int=k, bias=c, l2_var=lv, l2_beta=beta,
             l2_contrib=l2_contrib, sigma=sig, sigma_used=sig_use,
             probs=probs, fc_ens=float(np.nanmean(x)), n_train=len(y))
    if verbose:
        print('=' * 64)
        print(f"  {R['name']}（{st}） 目标日 {R['date']}   [MOS 模型]")
        print('=' * 64)
        print(f"  9家模式等权 {R['fc_ens']:.2f}℃   偏差订正 {c:+.2f}℃"
              + (f"   L2({lv.replace('wx_','')})订正 {l2_contrib:+.2f}℃" if lv else ''))
        print(f"  连续预测 {score:.2f}℃   →   预计报出 {k}℃")
        print(f"  σ(模型/校正) {sig:.3f}/{sig_use:.3f}   训练 {R['n_train']} 天")
        print('  整数概率:')
        for kk in sorted(probs):
            if probs[kk] >= 0.005:
                print(f"    {kk:3d}℃ : {probs[kk]*100:5.1f}%  {'█'*int(probs[kk]*100/3)}")
        print()
    return R


# ================================================================ 生产预测
def predict_mos(st, target_date=None, verbose=True):
    """预测次日（或指定日）机场最高气温，输出整数档概率"""
    df = load_city(st)
    fcols = ['fc_' + m for m in MODES]

    # 目标行 = 有完整预报但无实测的最后一行
    cand = df[df['tmax_obs'].isna() & df[fcols].notna().all(axis=1)]
    if target_date:
        cand = df[df['date'] == pd.Timestamp(target_date)]
    if not len(cand):
        return None
    row = cand.iloc[-1]
    i = df.index[df['date'] == row['date']][0]

    tr = df.iloc[max(0, i - W_ROLL):i]
    X = tr[fcols].values.astype(float)
    yv = tr['tmax_obs'].values.astype(float)
    ok = ~(np.isnan(X).any(axis=1) | np.isnan(yv))
    X, yv = X[ok], yv[ok]

    lam = select_lam(X, yv)
    w = fit_simplex(X, yv, lam)

    # σ 与偏差用全训练期
    Xall = df.iloc[:i][fcols].values.astype(float)
    yall = df.iloc[:i]['tmax_obs'].values.astype(float)
    okall = ~(np.isnan(Xall).any(axis=1) | np.isnan(yall))
    mu_t = Xall[okall] @ w
    c = float((yall[okall] - mu_t).mean())
    resid = yall[okall] - mu_t - c
    sig = max(float(np.std(resid, ddof=1)), 0.4)

    x = row[fcols].values.astype(float)
    score = float(x @ w + c)
    k = int(round(score))

    # 上尾校正（真实变率大于残差σ）
    obs = df['tmax_obs'].dropna()
    true_std = obs.diff().dropna().std()
    sig_use = max(sig, true_std * 0.75)

    probs = {kk: float(norm.cdf(kk + 0.5, score, sig_use) - norm.cdf(kk - 0.5, score, sig_use))
             for kk in range(k - 4, k + 5)}
    s = sum(probs.values())
    probs = {a: b / s for a, b in probs.items()}

    R = dict(station=st, name=CITIES[st]['name'], date=str(pd.Timestamp(row['date']).date()),
             score=score, pred_int=k, c=c, sigma=sig, sigma_used=sig_use,
             lam=lam, probs=probs,
             fc_ens=float(np.nanmean(x)),
             weights={m: float(ww) for m, ww in zip(MODES, w)})
    if verbose:
        print('=' * 62)
        print(f"  {R['name']}（{st}） 目标日 {R['date']}")
        print('=' * 62)
        print(f"  连续预测 {score:.2f}℃   预计报出 {k}℃   （偏差订正 {c:+.2f}℃）")
        print(f"  等权集成 {R['fc_ens']:.2f}℃   σ(模型/校正) {sig:.3f}/{sig_use:.3f}")
        print(f"  收缩 λ={lam}")
        print('  各国权重:')
        for m, ww in sorted(R['weights'].items(), key=lambda x: -x[1])[:6]:
            if ww >= 0.01:
                print(f"    {ORIGIN[m]:16s} {ww*100:5.1f}%")
        print('  整数概率:')
        for kk in sorted(probs):
            if probs[kk] >= 0.005:
                print(f"    {kk:3d}℃ : {probs[kk]*100:5.1f}%  {'█'*int(probs[kk]*100/3)}")
        print()
    return R


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--st', default=None)
    ap.add_argument('--predict', action='store_true')
    ap.add_argument('--eval', action='store_true')
    ap.add_argument('--min-train', type=int, default=MIN_TRAIN)
    ap.add_argument('--final', action='store_true', help='用最终配置做生产预测')
    args = ap.parse_args()

    if args.final:
        print('\n########## MOS 最终配置预测 ##########\n')
        for st in (stations if args.st else list(CITIES)):
            predict_final(st)
        sys.exit(0)

    np.random.seed(SEED)
    stations = [args.st] if args.st else list(CITIES)
    if not args.predict:
        args.eval = True
    if args.eval:
        print('\n########## MOS 方案对比（walk-forward 样本外）##########\n')
        for st in stations:
            R = compare_schemes(st, args.min_train)
            print('=' * 78)
            print(f"  {CITIES[st]['name']}（{st}）  min_train={args.min_train}")
            print('=' * 78)
            print(f"  {'方案':14s} {'logloss':>9s} {'精确率':>8s} {'MAE':>7s} {'偏差':>7s} {'样本':>5s}")
            for s in ['equal', 'best_single', 'ridge', 'mos']:
                m = R[s]
                if m['n'] == 0:
                    continue
                print(f"  {s:14s} {m['ll']:9.4f} {m['acc']*100:7.1f}% {m['mae']:7.3f} "
                      f"{m['bias']:+7.2f} {m['n']:5d}")
            base, cur = R['equal'], R['mos']
            if base['n']:
                print(f"  → MOS 相对等权: Δll={cur['ll']-base['ll']:+.4f}  "
                      f"ΔMAE={cur['mae']-base['mae']:+.3f}  Δ精确={(cur['acc']-base['acc'])*100:+.1f}pp")
            print()
    if args.predict:
        print('\n########## MOS 生产预测 ##########\n')
        for st in stations:
            predict_mos(st)
