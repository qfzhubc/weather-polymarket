# -*- coding: utf-8 -*-
"""
京沪穗三地机场最高气温 · 每日一键流程（16:10 定时任务入口）
============================================================
【双模型并行对决】
  现有模型 tmax_unified  vs  MOS 订正模型 mos_model
  两者同时预测明日，写入对决台账；次日实况出来后自动回填误差。
  累积足够天数后即可用【线上真实对决数据】决定哪个模型胜出。

流程
  ① 采集当日快照（METAR + 9家模式预报 + 格点因子 + 海温）
  ② 更新实测库（拉取最近 METAR，算每日实测最高）
  ③ 现有模型滚动优化 + 预测
  ④ MOS 模型预测
  ⑤ 双模型对决台账：写入今日预测 + 回填已到期实况
  ⑥ 输出报告（含累计对决统计）

用法
  python3 daily_3city.py                    # 全流程（今天）
  python3 daily_3city.py --date 2026-10-17
  python3 daily_3city.py --no-snapshot      # 跳过采集
  python3 daily_3city.py --report-only      # 只出累计对决统计
"""
import os, sys, json, argparse, warnings, time
from datetime import datetime, timedelta

warnings.filterwarnings('ignore')
# 路径基准 = 脚本自身所在目录（便于部署到任意环境，如 GitHub Actions）
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import numpy as np
import pandas as pd

D3 = os.path.join(BASE, 'daily3')
LEDGER = os.path.join(D3, 'ledger.csv')
DUEL = os.path.join(D3, 'ledger_duel.csv')
OBSDB = os.path.join(D3, 'obs_daily.csv')
LOCK = os.path.join(D3, '.running.lock')
LOGF = None
STATIONS = ['ZBAA', 'ZSPD', 'ZGGG']
NAME = {'ZBAA': '北京首都', 'ZSPD': '上海浦东', 'ZGGG': '广州白云'}


def log(m):
    line = '[%s] %s' % (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), m)
    print(line, flush=True)
    if LOGF:
        try:
            with open(LOGF, 'a', encoding='utf-8') as f:
                f.write(line + '\n')
        except Exception:
            pass


def acquire_lock(max_age_min=40):
    """防止并发运行（定时任务与手动运行重叠会互相写坏台账）"""
    if os.path.exists(LOCK):
        try:
            age = time.time() - os.path.getmtime(LOCK)
        except Exception:
            age = 9e9
        if age < max_age_min * 60:
            return False
        try:
            os.remove(LOCK)          # 陈旧锁，清理
        except Exception:
            pass
    try:
        fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, ('pid=%s started=%s\n'
                      % (os.getpid(), datetime.now().isoformat())).encode())
        os.close(fd)
        return True
    except Exception:
        return False


def release_lock():
    try:
        os.remove(LOCK)
    except Exception:
        pass


# ============================================================ ① 快照
def step_snapshot(run_date):
    log('① 采集当日快照 ...')
    try:
        import snapshot_daily as SD
        SD.snapshot(run_date)
        log('   ✓ snapshots/%s.json' % run_date)
        return True
    except Exception as e:
        log('   !! 失败: %s' % e)
        return False


# ============================================================ ② 更新实测库
def step_update_obs(days=12):
    """拉取三城最近 METAR，按本地日聚合成每日实测最高，更新 obs_daily.csv"""
    log('② 更新实测库 ...')
    import requests
    TZ = 'Asia/Shanghai'
    rows = []
    for st in STATIONS:
        try:
            u = ('https://aviationweather.gov/api/data/metar?ids=%s&format=json&hours=%d'
                 % (st, days * 24 + 72))
            j = requests.get(u, timeout=90).json()
        except Exception as e:
            log('   !! %s 实测获取失败: %s' % (st, e))
            continue
        per = {}
        for o in (j or []):
            t = o.get('obsTime')
            temp = o.get('temp')
            if t is None or temp is None:
                continue
            d = pd.to_datetime(t, unit='s', utc=True).tz_convert(TZ).strftime('%Y-%m-%d')
            per.setdefault(d, []).append(temp)
        for d, vs in per.items():
            rows.append(dict(station=st, date=d, tmax_obs=max(vs), n_obs=len(vs)))
    if not rows:
        log('   !! 无实测数据')
        return None
    new = pd.DataFrame(rows)
    if os.path.exists(OBSDB):
        old = pd.read_csv(OBSDB)
        oi = set(zip(old['station'], old['date']))
        ni = set(zip(new['station'], new['date']))
        old = old[[k not in ni for k in oi]]
        new = pd.concat([old, new], ignore_index=True)
    new = (new.drop_duplicates(subset=['station', 'date'], keep='last')
              .sort_values(['station', 'date']).reset_index(drop=True))
    new.to_csv(OBSDB, index=False)
    log('   实测库 %d 行，最新 %s' % (len(new), new['date'].max()))
    return new


# ============================================================ ③ 现有模型
def step_optimize_old():
    log('③ 现有模型 tmax_unified 滚动优化 ...')
    import importlib, tmax_unified as TU
    importlib.reload(TU)
    out = {}
    for st in STATIONS:
        try:
            res, _, _ = TU.evaluate_city(st, verbose=False)
            out[st] = res
            log('   %s ll %.4f→%.4f 精确%.1f%% n=%d'
                % (res['name'], res['base_ll'], res['final_ll'],
                   res['final_acc'] * 100, res['n']))
        except Exception as e:
            log('   !! %s 失败: %s' % (st, e))
    return out


def step_predict_old(run_date):
    log('   现有模型预测 ...')
    import importlib, tmax_unified as TU
    importlib.reload(TU)
    td = (datetime.strptime(run_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
    preds = {}
    for st in STATIONS:
        try:
            r = TU.predict_next(st, verbose=False, run_date=run_date)
            if r is None:
                log('   !! %s 无预测' % st)
                continue
            # 关键校验：必须与 MOS 预测同一目标日，否则对决无意义
            if r['target_date'] != td:
                log('   ⚠ %s 现有模型目标日=%s，期望=%s → 跳过（缺 %s 快照）'
                    % (st, r['target_date'], td, run_date))
                continue
            preds[st] = r
        except Exception as e:
            log('   !! %s 现有模型预测失败: %s' % (st, e))
    return preds


# ============================================================ ④ MOS 模型
def step_predict_mos(run_date):
    log('④ MOS 模型预测 ...')
    import importlib, mos_model as MO
    importlib.reload(MO)
    td = (datetime.strptime(run_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
    preds = {}
    for st in STATIONS:
        try:
            preds[st] = MO.predict_final(st, target_date=td, verbose=False)
        except Exception as e:
            log('   !! %s MOS 预测失败: %s' % (st, e))
    return preds


# ============================================================ ⑤ 对决台账
def _pll(probs, kreal):
    p = probs.get(int(kreal))
    return float(-np.log(p)) if (p and p > 0) else np.nan


def step_predict_v2(run_date):
    log('   MOS 大样本模型 v2 预测 ...')
    import importlib, predict_v2 as P2
    importlib.reload(P2)
    td = (datetime.strptime(run_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
    preds = {}
    for st in STATIONS:
        try:
            preds[st] = P2.predict(st, target_date=td, verbose=False)
        except Exception as e:
            log('   !! %s v2 预测失败: %s' % (st, e))
    return preds


def step_duel(run_date, preds_old, preds_mos, preds_v2=None):
    """写入今日各模型预测；用最新实测回填已到期日子的误差"""
    log('⑤ 对决台账 ...')
    td = (datetime.strptime(run_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
    rows = []
    for mdl, preds in [('old', preds_old), ('mos', preds_mos), ('v2', preds_v2 or {})]:
        for st in STATIONS:
            p = preds.get(st)
            if not p:
                continue
            rows.append(dict(target_date=td, station=st, model=mdl, source='live',
                             pred=p['score'], pred_int=p['pred_int'],
                             sigma=p.get('sigma_used') or p.get('sigma'),
                             probs=json.dumps({str(k): round(v, 5)
                                               for k, v in p['probs'].items()})))
    if not rows:
        log('   !! 无预测可写')
        return None
    new = pd.DataFrame(rows)

    if os.path.exists(DUEL):
        L = pd.read_csv(DUEL)
        nk = set(zip(new['station'], new['target_date'], new['model']))
        keep = [k not in nk for k in zip(L['station'], L['target_date'], L['model'])]
        L = pd.concat([L[keep], new], ignore_index=True)
    else:
        L = new

    # ---- 回填实测
    for c in ['real', 'err', 'll', 'acc']:
        if c not in L.columns:
            L[c] = np.nan
    # ---- 回填实测：只回填【已完整过去】且【观测样本充足】的日子
    #      （今天最高温通常 14-16 时才出现，当日不能使用，否则系统性低估）
    today = pd.Timestamp(datetime.now().strftime('%Y-%m-%d'))
    # 当日是否允许回填：日最高通常 14-16 时出现，16 点后（定时任务时段）可回填当日，
    # 但要求观测条数足够（>=20），避免清晨/上午误把低温当最高。
    allow_today = datetime.now().hour >= 16
    n_back = 0
    if os.path.exists(OBSDB):
        obs = pd.read_csv(OBSDB)
        obs['date'] = obs['date'].astype(str)
        oi = obs.set_index(['station', 'date'])['tmax_obs']
        oin = obs.set_index(['station', 'date'])['n_obs'] if 'n_obs' in obs.columns else None
        for i, r in L.iterrows():
            if pd.notna(r['real']):
                continue
            tdv = str(r['target_date'])
            td_ts = pd.Timestamp(tdv)
            if td_ts > today:                        # 未来，跳过
                continue
            if td_ts == today and not allow_today:   # 当日且未到 16 点
                continue
            k = (r['station'], tdv)
            if k not in oi.index or pd.isna(oi.loc[k]):
                continue
            if oin is not None:
                nn = oin.loc[k]
                need = 20 if td_ts == today else 16  # 当日要求更严
                if pd.isna(nn) or float(nn) < need:
                    continue
            L.at[i, 'real'] = float(oi.loc[k])
            n_back += 1
    log('   本次回填 %d 行' % n_back)

    # ---- 算误差指标
    for i, r in L.iterrows():
        if pd.isna(r['real']):
            continue
        real = float(r['real'])
        L.at[i, 'err'] = float(r['pred']) - real
        try:
            pr = json.loads(r['probs']) if isinstance(r['probs'], str) else {}
            pr = {int(k): v for k, v in pr.items()}
            L.at[i, 'll'] = _pll(pr, int(round(real)))
        except Exception:
            pass
        L.at[i, 'acc'] = 1.0 if int(r['pred_int']) == int(round(real)) else 0.0

    L = (L.drop_duplicates(subset=['station', 'target_date', 'model'], keep='last')
           .sort_values(['target_date', 'station', 'model']).reset_index(drop=True))
    L.to_csv(DUEL, index=False)

    v = L[L['real'].notna()]
    log('   台账 %d 行；已回填实况 %d 行（%d 个目标日）'
        % (len(L), len(v), v['target_date'].nunique()))
    return L


def duel_summary(L):
    if L is None or not len(L):
        return None
    v = L[L['real'].notna()]
    if not len(v):
        return None
    rows = []
    for st in STATIONS:
        s = v[v['station'] == st]
        for src in ['live', 'backfill']:
            s2 = s[s['source'] == src] if 'source' in s.columns else s[s.index < 0]
            if not len(s2):
                continue
            for mdl in ['old', 'mos', 'v2']:
                d = s2[s2['model'] == mdl]
                if not len(d):
                    continue
                rows.append(dict(station=st, model=mdl, source=src, n=len(d),
                                 ll=float(d['ll'].mean()), acc=float(d['acc'].mean()),
                                 mae=float(d['err'].abs().mean()),
                                 bias=float(d['err'].mean())))
    return pd.DataFrame(rows)


# ============================================================ ⑥ 报告
def step_report(run_date, preds_old, preds_mos, L, opt=None, preds_v2=None):
    td = (datetime.strptime(run_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
    pv = preds_v2 or {}
    lines = ['# 京沪穗三地机场次日最高气温 · 三模型预测\n']
    lines.append('- 数据基准日（今日）：**%s**' % run_date)
    lines.append('- 预测目标日（明日）：**%s**' % td)
    lines.append('- 生成时间：%s\n' % datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    lines.append('| 机场 | 今日实测 | 现有模型 | MOS小样本 | MOS大样本v2 | v2最可能 |')
    lines.append('|---|---|---|---|---|---|')
    for st in STATIONS:
        po, pm, p2 = preds_old.get(st), preds_mos.get(st), pv.get(st)
        if not (po or pm or p2):
            continue
        o = '%d℃' % po['pred_int'] if po else '—'
        m = '%d℃' % pm['pred_int'] if pm else '—'
        v = '%d℃' % p2['pred_int'] if p2 else '—'
        top = '—'
        if p2:
            t = sorted(p2['probs'].items(), key=lambda x: -x[1])[0]
            top = '%d℃ %.0f%%' % (t[0], t[1] * 100)
        an = po.get('anchor') if po else None
        an = ('%.0f℃' % an) if (an is not None and pd.notna(an)) else '—'
        lines.append('| %s(%s) | %s | %s | %s | **%s** | %s |'
                     % (NAME[st], st, an, o, m, v, top))

    lines.append('\n## 明日预测详情\n')
    for st in STATIONS:
        po, pm = preds_old.get(st), preds_mos.get(st)
        p2 = pv.get(st)
        lines.append('### %s（%s）' % (NAME[st], st))
        # ---- 天气诊断：晴朗/辐射/云量，便于理解当日升温机制
        try:
            fp = os.path.join(BASE, 'snapshots', '%s.json' % run_date)
            snap = json.load(open(fp, encoding='utf-8'))
            c = snap['cities'][st]
            g = c.get('grid_today', {}) or {}
            nd = c.get('next_day_pred', {}) or {}
            lines.append('- 天气诊断：今日 低云 **%.0f%%** / 降水 %.1fmm / 正午辐射 %.0f W·m⁻²'
                         ' ｜ 明日预报云量 **%.0f%%**'
                         % (g.get('cloud_low_pm', 0), g.get('precip_sum', 0),
                            g.get('sw_noon', 0), nd.get('best_match_cloud', 0)))
        except Exception:
            pass
        if po:
            lines.append('- 因子模型：连续 %.2f℃ → **%d℃**（σ=%.3f）'
                         % (po['score'], po['pred_int'], po['sigma_used']))
        if pm:
            ext = (' + 辐射订正 %+.2f℃' % pm['l2_contrib']) if pm.get('l2_var') else ''
            lines.append('- MOS小样本：模式等权 %.2f℃ + 偏差 %+.2f℃%s → 连续 %.2f℃ → **%d℃**（σ=%.3f）'
                         % (pm['fc_ens'], pm['bias'], ext, pm['score'],
                            pm['pred_int'], pm['sigma_used']))
        if p2:
            lines.append('- MOS大样本v2：连续 %.2f℃ → **%d℃**（σ=%.3f）'
                         % (p2['score'], p2['pred_int'],
                            p2.get('sigma_used') or p2.get('sigma') or 0))

        # ---- 三模型 · 四档温度概率对比
        lines.append('\n**各模型四档温度概率**（每个模型自身概率最高的四个整数档，按温度升序）\n')
        lines.append('| 模型 | 最可能 | 次可能 | 第三档 | 第四档 |')
        lines.append('|---|---|---|---|---|')
        for p, lbl in [(po, '因子模型'), (pm, 'MOS小样本'), (p2, 'MOS大样本v2')]:
            if not p:
                continue
            pr = p.get('probs') or {}
            top = sorted(((int(k), float(v)) for k, v in pr.items()),
                         key=lambda x: -x[1])[:4]
            top = sorted(top, key=lambda x: x[0])
            cells = ['%d℃ %.0f%%' % (k, v * 100) for k, v in top]
            while len(cells) < 4:
                cells.append('—')
            lines.append('| %s | %s |' % (lbl, ' | '.join(cells)))
        lines.append('')

    S = duel_summary(L)
    if S is not None and len(S):
        LBL = [('old', '因子模型'), ('mos', 'MOS小样本'), ('v2', 'MOS大样本v2')]
        # ---- ① 实时对决（证据价值高）
        Sl = S[S['source'] == 'live']
        if len(Sl):
            lines.append('## ① 实时对决（live：每日真实发布、事后回填实况）\n')
            lines.append('> 这是唯一能公正裁决三模型的证据。目标：累积 ≥60 天下结论。\n')
            lines.append('| 机场 | 模型 | 天数 | logloss | 精确率 | MAE | 偏差 |')
            lines.append('|---|---|---|---|---|---|---|')
            for st in STATIONS:
                for mdl, lbl in LBL:
                    d = Sl[(Sl['station'] == st) & (Sl['model'] == mdl)]
                    if len(d):
                        r = d.iloc[0]
                        lines.append('| %s | %s | %d | %.4f | %.1f%% | %.3f | %+.2f |'
                                     % (NAME[st], lbl, r['n'], r['ll'], r['acc'] * 100,
                                        r['mae'], r['bias']))
            nl = int(Sl.groupby('station')['n'].max().min()) if len(Sl) else 0
            lines.append('\n- 实时样本累积：**%d 天**（%s）'
                         % (nl, '尚不足以定案，继续累积' if nl < 60 else '已达决策门槛'))
            lines.append('')
        # ---- ② 回测对决（证据价值低，仅参考）
        Sb = S[S['source'] == 'backfill']
        if len(Sb):
            lines.append('## ② 回测对决（backfill：历史数据回放，仅供参考）\n')
            lines.append('> ⚠️ 各模型参数均在自己的回测集上调过，成绩天然虚高，**不能用于裁决胜负**。\n')
            lines.append('| 机场 | 模型 | 天数 | logloss | 精确率 | MAE | 偏差 |')
            lines.append('|---|---|---|---|---|---|---|')
            for st in STATIONS:
                for mdl, lbl in LBL:
                    d = Sb[(Sb['station'] == st) & (Sb['model'] == mdl)]
                    if len(d):
                        r = d.iloc[0]
                        lines.append('| %s | %s | %d | %.4f | %.1f%% | %.3f | %+.2f |'
                                     % (NAME[st], lbl, r['n'], r['ll'], r['acc'] * 100,
                                        r['mae'], r['bias']))
            lines.append('')
        # ---- 态势（优先用 live，不足则用 backfill 并标注）
        base = Sl if len(Sl) else Sb
        tag_src = '实时' if len(Sl) else '回测'
        bullets = []
        for st in STATIONS:
            d = base[base['station'] == st]
            if len(d) < 2:
                continue
            best = d.loc[d['ll'].idxmin()]
            worst = d.loc[d['ll'].idxmax()]
            n = int(best['n'])
            nm = dict(LBL).get(best['model'], best['model'])
            note = ('样本充足，可决策' if n >= 60 else
                    '样本中等' if n >= 30 else '样本尚少，仅参考')
            bullets.append('- **%s**：当前领先 **%s**（ll=%.4f，最弱 %.4f），%s样本 %d 天 — %s'
                           % (NAME[st], nm, best['ll'], worst['ll'], tag_src, n, note))
        if bullets:
            lines.append('**对决态势**\n')
            lines += bullets
            lines.append('')

    if opt:
        lines.append('## 现有模型滚动优化状态\n')
        lines.append('| 机场 | 基线ll | 优化后ll | 精确率 | p |')
        lines.append('|---|---|---|---|---|')
        for st in STATIONS:
            if st in opt:
                o = opt[st]
                lines.append('| %s | %.4f | %.4f | %.1f%% | %.3f |'
                             % (o['name'], o['base_ll'], o['final_ll'],
                                o['final_acc'] * 100, o['p']))

    md = '\n'.join(lines)
    fp = os.path.join(D3, '双模型预测_%s.md' % run_date)
    open(fp, 'w', encoding='utf-8').write(md)
    log('报告 → %s' % fp)

    rows = []
    for st in STATIONS:
        po, pm = preds_old.get(st), preds_mos.get(st)
        rows.append(dict(base_date=run_date, target_date=td, station=st, name=NAME[st],
                         old_pred=(po['score'] if po else None),
                         old_int=(po['pred_int'] if po else None),
                         mos_pred=(pm['score'] if pm else None),
                         mos_int=(pm['pred_int'] if pm else None),
                         generated_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    nn = pd.DataFrame(rows)
    if os.path.exists(LEDGER):
        oo = pd.read_csv(LEDGER)
        nn = pd.concat([oo[oo['base_date'] != run_date], nn], ignore_index=True)
    nn.to_csv(LEDGER, index=False)
    return md


# ============================================================ main
def timed(name, fn, *args, **kw):
    """分步计时 + 单步异常不阻断全流程"""
    t = time.time()
    try:
        r = fn(*args, **kw)
        log('   ✓ %s 耗时 %.1fs' % (name, time.time() - t))
        return r
    except Exception as e:
        log('   !! %s 失败（%.1fs）：%s: %s' % (name, time.time() - t, type(e).__name__, e))
        return None


def main():
    global LOGF
    ap = argparse.ArgumentParser()
    ap.add_argument('--date', default=None)
    ap.add_argument('--no-snapshot', action='store_true')
    ap.add_argument('--report-only', action='store_true')
    ap.add_argument('--force', action='store_true', help='忽略并发锁强制执行')
    a = ap.parse_args()
    os.makedirs(D3, exist_ok=True)
    run_date = a.date or datetime.now().strftime('%Y-%m-%d')
    LOGF = os.path.join(D3, 'run_%s.log' % run_date)

    log('=' * 60)
    log('  京沪穗三地 · 双模型每日流程  run_date=%s  pid=%s' % (run_date, os.getpid()))
    log('=' * 60)

    if a.report_only:
        S = duel_summary(pd.read_csv(DUEL) if os.path.exists(DUEL) else None)
        print(S.to_string(index=False) if S is not None else '暂无对决数据')
        return 0

    if not a.force and not acquire_lock():
        log('!! 已有实例在运行（锁文件 %s），本次退出以避免并发写坏台账' % LOCK)
        log('!! 若确认无实例运行，删除该锁文件或加 --force 重试')
        return 2

    t0 = time.time()
    try:
        if not a.no_snapshot:
            timed('① 采集快照', step_snapshot, run_date)
        timed('② 更新实测库', step_update_obs)
        opt = timed('③ 现有模型滚动优化', step_optimize_old) or {}
        po = timed('④ 因子模型预测', step_predict_old, run_date) or {}
        pm = timed('④ MOS小样本预测', step_predict_mos, run_date) or {}
        pv = timed('④ MOS大样本v2预测', step_predict_v2, run_date) or {}
        L = timed('⑤ 对决台账', step_duel, run_date, po, pm, pv)
        md = timed('⑥ 生成报告', step_report, run_date, po, pm, L, opt, pv)
        if md:
            print('\n' + md)
        log('完成，总耗时 %.1fs' % (time.time() - t0))
        return 0
    except Exception as e:
        log('!! 流程异常终止：%s: %s' % (type(e).__name__, e))
        return 1
    finally:
        release_lock()


if __name__ == '__main__':
    sys.exit(main())
