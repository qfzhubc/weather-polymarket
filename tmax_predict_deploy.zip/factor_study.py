# -*- coding: utf-8 -*-
"""
京沪穗 最高气温影响因素研究（统一因子筛选框架）
================================================
目标：用现有数据（2026-08-15 ~ 2026-10-16）对用户提出的因子清单做「是否有效」的实证筛选。
方法：统一构造「明天-今天」变化量 Δfactor 与 Δtmax，分天气类型看相关性与分档单调性。
      —— 这是用户计划中"分析"环节的最小可行版本。
"""
import os, sys, json
import numpy as np
import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
CITIES = {
    'ZBAA': dict(name='北京首都', dir='beijing', lat=40.0801, lon=116.5846),
    'ZSPD': dict(name='上海浦东', dir='shanghai', lat=31.1443, lon=121.8083),
    'ZGGG': dict(name='广州白云', dir='', lat=23.3924,  lon=113.2988),
}
SKY = {'CLR':0.0,'SKC':0.0,'NSC':0.0,'NCD':0.0,'FEW':0.2,'SCT':0.4,'BKN':0.7,'OVC':1.0,'VV':1.0}


def load_metar(d):
    a = pd.read_csv(os.path.join(BASE, d, 'raw_download', 'asos_raw.csv'))
    a = a[pd.to_numeric(a['tmpf'], errors='coerce').notna()]
    a['valid'] = pd.to_datetime(a['valid'])
    a['date'] = a['valid'].dt.date.astype(str)
    n = lambda s: pd.to_numeric(a[s], errors='coerce')
    a['t_c'] = (n('tmpf') - 32) * 5/9
    stat = a.groupby('date').agg(tmax_obs=('t_c','max'), tmin_obs=('t_c','min'),
                                 tmean_obs=('t_c','mean')).reset_index()
    return stat


def build_features(d):
    """逐日因子宽表（格点 archive + 实测）"""
    ar = json.load(open(os.path.join(BASE, d, 'raw_download', 'archive.json')))
    dh = pd.DataFrame(ar['hourly']); dh['time'] = pd.to_datetime(dh['time'])
    dh['date'] = dh['time'].dt.date.astype(str); dh['h'] = dh['time'].dt.hour
    dd = pd.DataFrame(ar['daily']).rename(columns={
        'time':'date','temperature_2m_max':'tmax_ar','temperature_2m_min':'tmin_ar'})

    def agg(g):
        w = lambda lo,hi: g['h'].between(lo,hi)
        noon = w(11,14)
        # 云量分层
        out = {}
        out['cloud_day']   = g.loc[w(8,20),'cloud_cover'].mean()
        out['cloud_pm']    = g.loc[w(13,16),'cloud_cover'].mean()
        out['cloud_low_pm']= g.loc[w(13,16),'cloud_cover_low'].mean()
        # 辐射
        out['sw_day']      = g.loc[w(8,17),'shortwave_radiation'].mean()
        out['sw_noon']     = g.loc[noon,'shortwave_radiation'].mean()
        out['sw_sum']      = g.loc[w(8,17),'shortwave_radiation'].sum()
        # 风速风向（午后）
        pm = w(13,16)
        out['wind_pm']     = g.loc[pm,'wind_speed_10m'].mean()
        out['wind_max']    = g['wind_speed_10m'].max()
        wd = g.loc[noon,'wind_direction_10m'].mean()
        out['wind_dir']    = wd
        out['wind_u']      = -np.sin(np.radians(wd))   # 东西
        out['wind_v']      = -np.cos(np.radians(wd))   # 南北(北风 v<0)
        # 850hPa
        out['t850']        = g.loc[noon,'temperature_850hPa'].mean()
        out['t850_pm']     = g.loc[w(13,16),'temperature_850hPa'].mean()
        # 湿度/露点
        out['dew_min']     = g['dew_point_2m'].min()
        out['dew_pm']      = g.loc[pm,'dew_point_2m'].mean()
        out['rh_min']      = g['relative_humidity_2m'].min()
        out['tcwv']        = g['total_column_integrated_water_vapour'].mean()
        # 气压（锋面信号）
        out['mslp_mean']   = g['surface_pressure'].mean()
        out['mslp_min']    = g['surface_pressure'].min()
        out['mslp_max']    = g['surface_pressure'].max()
        # 降水
        out['precip']      = g['precipitation'].sum()
        return pd.Series(out)
    fa = dh.groupby('date').apply(agg).reset_index()
    df = dd.merge(fa, on='date', how='left')
    df = df.merge(load_metar(d), on='date', how='outer').sort_values('date').reset_index(drop=True)
    df['date'] = pd.to_datetime(df['date'])
    # 派生
    df['dtr'] = df['tmax_ar'] - df['tmin_ar']
    df['dayofyear'] = df['date'].dt.dayofyear
    return df


def make_delta(df):
    """构造 Δ(明天-今天) 面板"""
    fcols = [c for c in df.columns if c not in ('date','tmax_obs','tmin_obs','tmean_obs')]
    d = df.copy()
    for c in ['tmax_obs'] + fcols:
        if c in df.columns:
            d['next_' + c] = df[c].shift(-1)
    d['d_tmax'] = d['next_tmax_obs'] - d['tmax_obs']
    for c in fcols:
        if 'next_'+c in d.columns:
            d['d_' + c] = d['next_'+c] - d[c]
    return d.dropna(subset=['d_tmax'])


def screen(df, city):
    """单因子筛选：Δfactor vs Δtmax 相关 + 分档单调性"""
    cols = [c[2:] for c in df.columns if c.startswith('d_') and c != 'd_tmax']
    rows = []
    for c in cols:
        x = df[['d_'+c, 'd_tmax']].dropna()
        if len(x) < 15:
            rows.append(dict(factor=c, n=len(x), r=np.nan, mono='样本不足'))
            continue
        r = x['d_'+c].corr(x['d_tmax'])
        # 分档单调性
        try:
            x['bin'] = pd.qcut(x['d_'+c], 3, duplicates='drop')
            means = x.groupby('bin', observed=True)['d_tmax'].mean().values
            mono = '递增' if len(means)==3 and means[0]<means[1]<means[2] else \
                   ('递减' if len(means)==3 and means[0]>means[1]>means[2] else '非单调')
        except Exception:
            mono = '分档失败'
        rows.append(dict(factor=c, n=len(x), r=round(r,3), mono=mono))
    R = pd.DataFrame(rows).sort_values('r', key=lambda s: s.abs(), ascending=False)
    return R


if __name__ == '__main__':
    for st, cfg in CITIES.items():
        df = build_features(cfg['dir'])
        d = make_delta(df)
        R = screen(d, st)
        print('='*68)
        print(f'  {cfg["name"]}（{st}）  样本 n={len(d)}  '
              f'期间 {df["date"].min().date()} ~ {df["date"].max().date()}')
        print('='*68)
        mx = d['d_tmax'].std()
        print(f'  Δtmax std={mx:.2f}℃  均值={d["d_tmax"].mean():+.2f}℃')
        print(R.to_string(index=False))
        print()
