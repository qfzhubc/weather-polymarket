# -*- coding: utf-8 -*-
"""
多模式动态纠偏加权集成（9 家数值预报）
=====================================
覆盖机构：ECMWF(IFS) / ECMWF(AIFS,AI) / 德国 ICON / 英国 UKMO / 法国 Météo-France
         美国 GFS / 加拿大 GEM / 日本 JMA / 中国 CMA

核心思想
--------
各家模式对华南日最高气温普遍存在系统性偏冷（约 -0.6 ~ -2.8 ℃），
且不同模式偏差幅度差异很大。因此需要两步处理：

  1. **纠偏（bias correction）**：用「该模式最近 N 天预报值 − 实测值」的
     指数加权平均，估计其当前系统性偏差，从预报值中扣除。
  2. **加权（weighting）**：纠偏后仍有余差，按残余 MAE 的倒数平方分配权重
     （w ∝ 1/(MAE+ridge)²），近期误差小的模式获得更大话语权。

严格防数据泄漏：所有纠偏量与权重只用预测时点「之前」的数据估计。
"""
import json
import numpy as np
import pandas as pd

# 模式标识 → 中文名
MODES = {
    'ecmwf_ifs025':        'ECMWF IFS',
    'ecmwf_aifs025_single': 'ECMWF AIFS',
    'icon_seamless':       '德国ICON',
    'ukmo_seamless':       '英国UKMO',
    'meteofrance_seamless': '法国MF',
    'gfs_seamless':        '美国GFS',
    'gem_seamless':        '加拿大GEM',
    'jma_seamless':        '日本JMA',
    'cma_grapes_global':   '中国CMA',
}
MODE_IDS = list(MODES.keys())
MULTIMODEL_URL = (
    'https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}'
    '&daily=temperature_2m_max,temperature_2m_min,cloud_cover_mean,'
    'shortwave_radiation_sum,wind_speed_10m_max,precipitation_sum'
    '&timezone=Asia%2FShanghai&past_days={pd}&forecast_days={fd}'
    '&models=' + ','.join(MODE_IDS)
)


def parse_multimodel(path):
    """解析多模式返回，整理成 date × 模式 的 DataFrame"""
    d = json.load(open(path))
    if 'error' in d:
        raise RuntimeError('多模式接口报错: %s' % d)
    t = pd.to_datetime(d['daily']['time'])
    M = pd.DataFrame({'date': t})
    for m in MODE_IDS:
        k = 'temperature_2m_max_' + m
        M[m] = d['daily'].get(k, [np.nan] * len(t))
        # 部分模式（如 cma/gem）键名可能带 suff，做一次模糊兜底
        if k not in d['daily']:
            for kk in d['daily']:
                if kk.endswith(m) and 'temperature_2m_max' in kk:
                    M[m] = d['daily'][kk]
                    break
    return M


def fit_weights(M, asof, lookback=30, half_life=10.0, min_n=5, ridge=0.05):
    """按 asof 之前的数据，估计各家模式的纠偏量与权重（防泄漏）

    参数
      lookback  : 回看天数（只用最近 N 天计算误差）
      half_life : 指数衰减半衰期（天），越小越看重最近表现
      min_n     : 有效样本下限，低于此值该模式当日不参与
      ridge     : 权重分母平滑项，防止 MAE 极小时权重爆炸

    返回
      info : {模式: {bias, mae, n, ok}}
      W    : {模式: 归一化权重}，仅含可用模式
    """
    hist = M[(M['date'] < asof) & M['tmax_obs'].notna()].tail(lookback)
    info = {}
    for m in MODE_IDS:
        h = hist[hist[m].notna()]
        if len(h) < min_n:
            info[m] = {'bias': 0.0, 'mae': np.nan, 'n': len(h), 'ok': False}
            continue
        ww = np.exp(-np.log(2) * np.arange(len(h))[::-1] / half_life)
        e = h[m].values - h['tmax_obs'].values
        bias = float(np.average(e, weights=ww))
        mae = float(np.average(np.abs(e - bias), weights=ww))
        info[m] = {'bias': bias, 'mae': mae, 'n': int(len(h)), 'ok': True}

    ok = {m: v for m, v in info.items() if v['ok'] and np.isfinite(v['mae'])}
    if not ok:
        return info, {}
    raw = {m: 1.0 / (v['mae'] + ridge) ** 2 for m, v in ok.items()}
    s = sum(raw.values())
    return info, {m: v / s for m, v in raw.items()}


def ensemble_predict(M, asof, lookback=30, half_life=10.0, detail=False,
                     target_date=None):
    """给出集成预报

    参数
      asof        : 「信息截止日」。纠偏与权重只用 M['date'] < asof 的数据估计。
                    调用方传入基准日 T，即可严格防泄漏。
      target_date : 「要读取哪一行的模式预报」。默认为 asof（当日预报）。
                    做次日(T+1)预报时，应传 target_date = asof + 1 天。

    返回 (pred, info, W, n_used)；detail=True 时额外返回各模式纠偏后取值
    """
    info, W = fit_weights(M, asof, lookback, half_life)
    td = asof if target_date is None else pd.Timestamp(target_date)
    row = M[M['date'] == td]
    if row.empty or not W:
        return (np.nan, info, W, 0, {}) if detail else (np.nan, info, W, 0)
    row = row.iloc[0]
    num = den = 0.0
    contrib = {}
    for m, w in W.items():
        v = row[m]
        if pd.isna(v):
            continue
        corr = float(v) - info[m]['bias']
        contrib[m] = {'raw': float(v), 'bias': info[m]['bias'],
                      'corrected': corr, 'weight': w}
        num += w * corr
        den += w
    pred = num / den if den > 0 else np.nan
    if detail:
        return pred, info, W, den, contrib
    return pred, info, W, den


def backtest(M, start, end=None):
    """时序回测：逐日用当时可得数据估计权重并预测，评估集成精度"""
    M = M.sort_values('date').reset_index(drop=True)
    sel = M[(M['date'] >= pd.Timestamp(start)) & M['tmax_obs'].notna()]
    if end:
        sel = sel[sel['date'] <= pd.Timestamp(end)]
    rows = []
    for dt in sel['date']:
        p, info, W, den = ensemble_predict(M, dt)
        if np.isnan(p):
            continue
        a = M.loc[M['date'] == dt, 'tmax_obs'].iloc[0]
        rows.append({'date': dt, 'pred': p, 'actual': float(a),
                     'error': p - float(a), 'abs_error': abs(p - float(a))})
    return pd.DataFrame(rows)


def mode_stats(M, start=None, end=None):
    """各单一模式在指定区间的误差统计（用于对照与报告）"""
    sub = M[M['tmax_obs'].notna()].copy()
    if start:
        sub = sub[sub['date'] >= pd.Timestamp(start)]
    if end:
        sub = sub[sub['date'] <= pd.Timestamp(end)]
    out = []
    for m in MODE_IDS:
        h = sub[sub[m].notna()]
        if len(h) == 0:
            out.append({'mode': m, 'name': MODES[m], 'MAE': np.nan, 'Bias': np.nan,
                        'RMSE': np.nan, 'n': 0})
            continue
        e = h[m].values - h['tmax_obs'].values
        out.append({'mode': m, 'name': MODES[m],
                    'MAE': float(np.abs(e).mean()), 'Bias': float(e.mean()),
                    'RMSE': float(np.sqrt((e ** 2).mean())), 'n': int(len(h))})
    return pd.DataFrame(out).sort_values('MAE').reset_index(drop=True)
