# -*- coding: utf-8 -*-
"""
三城每日快照采集器（京 ZBAA / 沪 ZSPD / 穗 ZGGG）
====================================================
目的：积累建模所需数据（当前仅 2 个月，且 t850 无法回填，只能从此日起积累）。

每个运行日 16:00 抓取并归档：
  1. 当日机场实况 METAR（aviationweather 近实时 + Iowa State 当日 ASOS）
  2. 次日预报快照（9 家多模式 + best_match）
  3. 格点因子（archive：云分层/辐射/风/湿度/气压；注意 t850 历史缺失）
  4. 海温（各机场邻近海域）
  5. t850（forecast 接口，仅当日往后可用）

存储：snapshots/YYYY-MM-DD.json（一日一文件，永久保留）
      snapshots/_index.csv（汇总索引，便于后续拼装长序列）

用法：
  python3 snapshot_daily.py                # 抓取今天
  python3 snapshot_daily.py --date 2026-10-16
"""
import os, sys, json, argparse
from datetime import datetime, timedelta, date
import numpy as np
import pandas as pd
import requests

BASE = os.path.dirname(os.path.abspath(__file__))
SNAP = os.path.join(BASE, 'snapshots')
TZ = 'Asia/Shanghai'

# 三城配置：METAR 站号 + 格点坐标 + 邻近海区（海温）
CITIES = {
    'ZBAA': dict(name='北京首都', lat=40.0801, lon=116.5846,
                 sea=dict(name='渤海湾', lat=38.5, lon=119.0)),
    'ZSPD': dict(name='上海浦东', lat=31.1443, lon=121.8083,
                 sea=dict(name='长江口外', lat=31.0, lon=122.0)),
    'ZGGG': dict(name='广州白云', lat=23.3924, lon=113.2988,
                 sea=dict(name='珠江口外', lat=22.0, lon=113.8)),
}

MODES = ["ecmwf_ifs025","ecmwf_aifs025_single","icon_seamless","ukmo_seamless",
         "meteofrance_seamless","gfs_seamless","gem_seamless","jma_seamless","cma_grapes_global"]


def log(m):
    print('[%s] %s' % (datetime.now().strftime('%H:%M:%S'), m), flush=True)


def get_json(url, timeout=90, retries=2):
    for i in range(retries):
        try:
            r = requests.get(url, timeout=timeout)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            if i == retries - 1:
                log('  !! 请求失败 %s' % e)
                return None
    return None


# ----------------------------------------------------------- 1. 当日实况 METAR
def fetch_metar(st, run_date):
    """近实时 METAR（aviationweather），只保留 run_date 当天（北京时间）"""
    u = 'https://aviationweather.gov/api/data/metar?ids=%s&format=json&hours=30' % st
    j = get_json(u, timeout=60)
    rows = []
    for o in (j or []):
        t = o.get('obsTime')
        if t is None:
            continue
        dt = pd.to_datetime(t, unit='s', utc=True).tz_convert(TZ)
        rows.append({'time_local': dt.strftime('%Y-%m-%d %H:%M'),
                     'date': dt.strftime('%Y-%m-%d'),
                     'temp': o.get('temp'), 'dewp': o.get('dewp'),
                     'wdir': o.get('wdir'), 'wspd': o.get('wspd'),
                     'raw': o.get('rawOb')})
    df = pd.DataFrame(rows)
    if not len(df):
        return df
    df = df[df['date'] == run_date]
    return df.sort_values('time_local').reset_index(drop=True)


# ----------------------------------------------------------- 2. 预报快照
def fetch_forecast(cfg, run_date):
    """9 家多模式 + best_match，取 T+0/T+1 两天的日最高"""
    out = {}
    lat, lon = cfg['lat'], cfg['lon']
    # best_match
    u = ('https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s'
         '&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,'
         'cloud_cover_mean,shortwave_radiation_sum,wind_speed_10m_max'
         '&timezone=Asia%%2FShanghai&past_days=1&forecast_days=3' % (lat, lon))
    j = get_json(u)
    if j and 'daily' in j:
        out['best_match'] = j['daily']
    # 9 家多模式（逐日）
    u2 = ('https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s'
          '&daily=temperature_2m_max&timezone=Asia%%2FShanghai&past_days=1&forecast_days=3'
          '&models=' % (lat, lon)) + ','.join(MODES)
    j2 = get_json(u2, timeout=90)
    if j2 and 'daily' in j2:
        d = j2['daily']
        ens = {}
        for m in MODES:
            k = 'temperature_2m_max_' + m
            if k in d:
                ens[m] = d[k]
        out['multimodel_daily'] = {'time': d['time'], **ens}
    return out


def fetch_multimodel_vars(cfg, run_date):
    """拉取【各模式自己发布的】daily 辅助变量，用于大样本 MOS 模型的 wx_* 特征。
    注意：必须与训练数据(hist, 来自 previous-runs API)同源 —— 都是各模式的平均，
          不能用 best_match 单模式顶替，否则生产/训练特征不一致。"""
    lat, lon = cfg['lat'], cfg['lon']
    vars_ = ['temperature_2m_max', 'temperature_2m_min', 'cloud_cover_mean',
             'shortwave_radiation_sum', 'wind_speed_10m_max', 'precipitation_sum']
    u = ('https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s'
         '&daily=%s&timezone=Asia%%2FShanghai&past_days=1&forecast_days=3'
         '&models=' % (lat, lon, ','.join(vars_))) + ','.join(MODES)
    j = get_json(u, timeout=90)
    if not j or 'daily' not in j:
        return None
    return j['daily']


# ----------------------------------------------------------- 3. 格点因子 + t850
def fetch_grid(cfg, run_date):
    lat, lon = cfg['lat'], cfg['lon']
    u = ('https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s'
         '&hourly=temperature_2m,relative_humidity_2m,dew_point_2m,precipitation,'
         'cloud_cover,cloud_cover_low,cloud_cover_mid,cloud_cover_high,'
         'wind_speed_10m,wind_direction_10m,wind_gusts_10m,'
         'shortwave_radiation,direct_radiation,diffuse_radiation,'
         'temperature_850hPa,total_column_integrated_water_vapour,'
         'surface_pressure,boundary_layer_height,sunshine_duration'
         '&timezone=Asia%%2FShanghai&past_days=2&forecast_days=3' % (lat, lon))
    j = get_json(u, timeout=90)
    return j.get('hourly') if j else None


# ----------------------------------------------------------- 4. 海温
def fetch_sst(sea, run_date):
    u = ('https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s'
         '&hourly=sea_surface_temperature&timezone=Asia%%2FShanghai'
         '&past_days=2&forecast_days=3' % (sea['lat'], sea['lon']))
    j = get_json(u, timeout=90)
    if not j or 'hourly' not in j:
        # 退回 marine-api
        u2 = ('https://marine-api.open-meteo.com/v1/marine?latitude=%s&longitude=%s'
              '&hourly=sea_surface_temperature&timezone=Asia%%2FShanghai'
              '&past_days=2&forecast_days=3' % (sea['lat'], sea['lon']))
        j = get_json(u2, timeout=90)
    return j.get('hourly') if j and 'hourly' in j else None


# ----------------------------------------------------------- 主流程
def snapshot(run_date):
    os.makedirs(SNAP, exist_ok=True)
    rec = {'run_date': run_date, 'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
           'cities': {}}
    for st, cfg in CITIES.items():
        log('抓取 %s（%s）' % (cfg['name'], st))
        metar = fetch_metar(st, run_date)
        obs_max = float(metar['temp'].max()) if len(metar) else None
        obs_n = int(len(metar))
        log('  METAR %d 条，当日已见最高 %s' % (obs_n, obs_max))

        fc = fetch_forecast(cfg, run_date)
        grid = fetch_grid(cfg, run_date)
        sst = fetch_sst(cfg['sea'], run_date)

        # 计算次日预报摘要
        next_day_pred = {}
        if 'best_match' in fc:
            bm = fc['best_match']
            try:
                i = bm['time'].index((datetime.strptime(run_date, '%Y-%m-%d')+timedelta(days=1)).strftime('%Y-%m-%d'))
                next_day_pred['best_match_tmax'] = bm['temperature_2m_max'][i]
                next_day_pred['best_match_cloud'] = bm.get('cloud_cover_mean', [None]*len(bm['time']))[i]
                next_day_pred['best_match_precip'] = bm.get('precipitation_sum', [None]*len(bm['time']))[i]
            except Exception:
                pass
        if 'multimodel_daily' in fc:
            mm = fc['multimodel_daily']
            try:
                i = mm['time'].index((datetime.strptime(run_date, '%Y-%m-%d')+timedelta(days=1)).strftime('%Y-%m-%d'))
                vals = [mm[m][i] for m in MODES if m in mm and mm[m][i] is not None]
                if vals:
                    next_day_pred['ens_mean'] = round(float(np.mean(vals)), 2)
                    next_day_pred['ens_min'] = float(min(vals))
                    next_day_pred['ens_max'] = float(max(vals))
                    next_day_pred['ens_n'] = len(vals)
            except Exception:
                pass

        # 当日格点摘要
        grid_today = {}
        if grid and 'time' in grid:
            df = pd.DataFrame(grid)
            df['date'] = df['time'].str[:10]
            g = df[df['date'] == run_date]
            if len(g):
                grid_today = {
                    't2m_max': float(g['temperature_2m'].max()) if 'temperature_2m' in g else None,
                    't850_noon': float(pd.to_numeric(g[g['time'].str[11:13].astype(int).between(11,14)]['temperature_850hPa'], errors='coerce').mean()) if 'temperature_850hPa' in g else None,
                    'cloud_low_pm': float(pd.to_numeric(g[g['time'].str[11:13].astype(int).between(13,16)]['cloud_cover_low'], errors='coerce').mean()) if 'cloud_cover_low' in g else None,
                    'cloud_mid_pm': float(pd.to_numeric(g[g['time'].str[11:13].astype(int).between(13,16)]['cloud_cover_mid'], errors='coerce').mean()) if 'cloud_cover_mid' in g else None,
                    'cloud_high_pm': float(pd.to_numeric(g[g['time'].str[11:13].astype(int).between(13,16)]['cloud_cover_high'], errors='coerce').mean()) if 'cloud_cover_high' in g else None,
                    'sw_noon': float(pd.to_numeric(g[g['time'].str[11:13].astype(int).between(11,14)]['shortwave_radiation'], errors='coerce').mean()) if 'shortwave_radiation' in g else None,
                    'blh_noon': float(pd.to_numeric(g[g['time'].str[11:13].astype(int).between(11,14)]['boundary_layer_height'], errors='coerce').mean()) if 'boundary_layer_height' in g else None,
                    'mslp_mean': float(pd.to_numeric(g['surface_pressure'], errors='coerce').mean()) if 'surface_pressure' in g else None,
                    'precip_sum': float(pd.to_numeric(g['precipitation'], errors='coerce').sum()) if 'precipitation' in g else None,
                }
        # 海温当日
        sst_today = None
        if sst and 'time' in sst:
            idx = [i for i, t in enumerate(sst['time']) if t.startswith(run_date)]
            vals = [sst['sea_surface_temperature'][i] for i in idx
                    if sst['sea_surface_temperature'][i] is not None]
            if vals:
                sst_today = round(float(np.mean(vals)), 2)

        rec['cities'][st] = {
            'name': cfg['name'], 'station': st,
            'obs_max_sofar': obs_max, 'obs_n': obs_n,
            'metar': metar.to_dict('records') if len(metar) else [],
            'next_day_pred': next_day_pred,
            'grid_today': grid_today,
            'sst_today': sst_today,
            'sst_area': cfg['sea']['name'],
            'raw_forecast': fc, 'raw_grid': grid, 'raw_sst': sst,
        }
        log('  次日预报: %s' % json.dumps(next_day_pred, ensure_ascii=False))
        log('  当日格点: %s' % json.dumps({k: (round(v,1) if isinstance(v,float) else v)
                                            for k,v in grid_today.items()}, ensure_ascii=False))
        log('  %s海温: %s℃' % (cfg['sea']['name'], sst_today))

    fp = os.path.join(SNAP, '%s.json' % run_date)
    json.dump(rec, open(fp, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    log('已保存 %s' % fp)

    # 更新索引 CSV
    idx_f = os.path.join(SNAP, '_index.csv')
    row = {'run_date': run_date, 'generated_at': rec['generated_at']}
    for st in CITIES:
        c = rec['cities'][st]
        row['%s_obsmax' % st] = c['obs_max_sofar']
        row['%s_ens' % st] = c['next_day_pred'].get('ens_mean')
        row['%s_bm' % st] = c['next_day_pred'].get('best_match_tmax')
        row['%s_sst' % st] = c['sst_today']
        row['%s_t850' % st] = c['grid_today'].get('t850_noon')
    if os.path.exists(idx_f):
        old = pd.read_csv(idx_f)
        old = old[old['run_date'] != run_date]
        new = pd.concat([old, pd.DataFrame([row])], ignore_index=True)
    else:
        new = pd.DataFrame([row])
    new.sort_values('run_date').to_csv(idx_f, index=False)
    log('索引已更新 %s（共 %d 天）' % (idx_f, len(new)))
    return rec


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--date', default=None)
    a = ap.parse_args()
    d = a.date or datetime.now().strftime('%Y-%m-%d')
    log('=' * 56)
    log('  三城每日快照  run_date=%s' % d)
    log('=' * 56)
    snapshot(d)
    log('完成')
